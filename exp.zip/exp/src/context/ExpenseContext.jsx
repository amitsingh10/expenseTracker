import React, { createContext, useContext, useState, useEffect } from 'react';
import { initialExpenses, categories, monthlyBudget, historicalMonthlyTotals } from '../data/mockData';

const ExpenseContext = createContext(null);

export function ExpenseProvider({ children }) {
  const [expenses, setExpenses] = useState(() => {
    const saved = localStorage.getItem('tracker_expenses');
    return saved ? JSON.parse(saved) : initialExpenses;
  });

  const [currentMonthIndex, setCurrentMonthIndex] = useState(5); // November (0-based in historical list)

  useEffect(() => {
    localStorage.setItem('tracker_expenses', JSON.stringify(expenses));
  }, [expenses]);

  const addExpense = (newExpense) => {
    const item = {
      id: `exp-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      ...newExpense,
      amount: parseFloat(newExpense.amount),
    };
    setExpenses((prev) => [item, ...prev]);
  };

  const deleteExpense = (id) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  const months = [
    { label: 'June 2026', short: 'Jun', key: '2026-06' },
    { label: 'July 2026', short: 'Jul', key: '2026-07' },
    { label: 'August 2026', short: 'Aug', key: '2026-08' },
    { label: 'September 2026', short: 'Sep', key: '2026-09' },
    { label: 'October 2026', short: 'Oct', key: '2026-10' },
    { label: 'November 2026', short: 'Nov', key: '2026-11' },
  ];

  const currentMonth = months[currentMonthIndex];

  // Filter expenses by selected month
  const activeMonthExpenses = expenses.filter((e) => {
    if (!e.date) return false;
    return e.date.startsWith(currentMonth.key);
  });

  // Calculate monthly total
  const monthlyTotal = activeMonthExpenses.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

  // Group by category
  const categoryTotals = categories.map((cat) => {
    const catExpenses = activeMonthExpenses.filter((e) => e.category.toLowerCase() === cat.name.toLowerCase());
    const total = catExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const count = catExpenses.length;
    const percentage = monthlyTotal > 0 ? (total / monthlyTotal) * 100 : 0;
    return {
      ...cat,
      total,
      count,
      percentage,
    };
  }).sort((a, b) => b.total - a.total);

  const topCategory = categoryTotals[0] || null;

  // Days in month calculation for daily average
  const daysInCurrentMonth = 30; // November
  const dailyAverage = monthlyTotal > 0 ? monthlyTotal / daysInCurrentMonth : 0;

  return (
    <ExpenseContext.Provider
      value={{
        expenses,
        activeMonthExpenses,
        categories,
        monthlyBudget,
        monthlyTotal,
        dailyAverage,
        topCategory,
        categoryTotals,
        months,
        currentMonthIndex,
        currentMonth,
        setCurrentMonthIndex,
        addExpense,
        deleteExpense,
        historicalMonthlyTotals,
      }}
    >
      {children}
    </ExpenseContext.Provider>
  );
}

export function useExpenses() {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error('useExpenses must be used within an ExpenseProvider');
  }
  return context;
}
