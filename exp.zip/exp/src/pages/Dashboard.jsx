import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { categories, formatCurrency } from '../data/mockData';
import { getExpenses, getBudget, setBudget } from '../data/storage';
import ExpenseListItem from '../components/ExpenseListItem';
import AddExpenseFab from '../components/AddExpenseFab';
import EmptyState from '../components/EmptyState';

export default function Dashboard() {
  const navigate = useNavigate();

  // Dynamic monthly budget from storage layer (defaults to 20000)
  const [monthlyBudget, setMonthlyBudget] = useState(() => getBudget());
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [budgetValue, setBudgetValue] = useState('');
  const [budgetError, setBudgetError] = useState('');

  const handleOpenEditBudget = () => {
    setBudgetValue(String(monthlyBudget));
    setBudgetError('');
    setIsEditingBudget(true);
  };

  const handleSaveBudget = (e) => {
    if (e) e.preventDefault();
    const numeric = parseFloat(budgetValue);
    if (!budgetValue || isNaN(numeric) || numeric <= 0) {
      setBudgetError('Please enter a valid budget amount greater than ₹0.');
      return;
    }
    setBudget(numeric);
    setMonthlyBudget(numeric);
    setIsEditingBudget(false);
    setBudgetError('');
  };
  // Use local time to determine the current month key (e.g. "2026-11")
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthNum = String(now.getMonth() + 1).padStart(2, '0');
  const currentMonthKey = `${currentYear}-${currentMonthNum}`;

  // Load live expenses from storage layer
  const allExpenses = getExpenses();

  // 1. Filter current month's expenses
  const monthExpenses = allExpenses.filter(
    (e) => e.date && e.date.startsWith(currentMonthKey)
  );

  // 2. Calculate this month's total spent
  const totalSpent = monthExpenses.reduce(
    (sum, item) => sum + (Number(item.amount) || 0),
    0
  );

  // 3. Budget calculations
  const budgetPercent = monthlyBudget > 0
    ? Number(((totalSpent / monthlyBudget) * 100).toFixed(1))
    : 0;

  const isOverBudget = totalSpent > monthlyBudget;
  const remainingAmount = monthlyBudget - totalSpent;

  // Exact requirement: Show "X left" or "X over budget"
  const remainingStatusText = isOverBudget
    ? `${formatCurrency(totalSpent - monthlyBudget)} over budget`
    : `${formatCurrency(remainingAmount)} left`;

  const remainingBalance = Math.max(0, remainingAmount);

  // Exact requirement: progress bar: green under 80%, amber 80-100%, red over
  const progressBarColor =
    budgetPercent < 80
      ? 'bg-emerald-500'
      : budgetPercent <= 100
      ? 'bg-amber-500'
      : 'bg-red-500';

  const badgeColor =
    budgetPercent < 80
      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
      : budgetPercent <= 100
      ? 'bg-amber-50 text-amber-700 border-amber-200'
      : 'bg-red-50 text-red-700 border-red-200';

  const todayDate = now.getDate(); // e.g. 18
  const daysInMonth = new Date(currentYear, now.getMonth() + 1, 0).getDate(); // e.g. 30
  const daysLeft = Math.max(1, daysInMonth - todayDate);
  const dailyAvg = todayDate > 0 ? Math.round(totalSpent / todayDate) : 0;
  const dailySafeSpend = daysLeft > 0 ? Math.round(remainingBalance / daysLeft) : 0;

  // 4. Calculate category breakdown for Donut chart & legend
  const categoryBreakdown = categories
    .map((cat) => {
      const catExpenses = monthExpenses.filter((e) => e.categoryId === cat.id);
      const catTotal = catExpenses.reduce(
        (sum, e) => sum + (Number(e.amount) || 0),
        0
      );
      const catPercent = totalSpent > 0 ? (catTotal / totalSpent) * 100 : 0;
      return {
        ...cat,
        amount: catTotal,
        percent: catPercent,
        count: catExpenses.length,
      };
    })
    .filter((cat) => cat.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  // 5. SVG Donut chart calculations (circumference = 2 * pi * 56 ≈ 351.86)
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  let cumulativePercent = 0;

  // 6. The 3 most recent expenses (sorted by date desc, then createdAt desc)
  const recentExpenses = [...allExpenses]
    .sort((a, b) => {
      if (b.date !== a.date) return b.date.localeCompare(a.date);
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    })
    .slice(0, 3);

  // Helper for human-readable date labels (Today, Yesterday, 14 Nov)
  const getDateLabel = (dateStr) => {
    const todayStr = `${currentYear}-${currentMonthNum}-${String(todayDate).padStart(2, '0')}`;
    const yesterdayDate = new Date(now);
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yStr = `${yesterdayDate.getFullYear()}-${String(yesterdayDate.getMonth() + 1).padStart(2, '0')}-${String(yesterdayDate.getDate()).padStart(2, '0')}`;

    if (dateStr === todayStr) return 'Today';
    if (dateStr === yStr) return 'Yesterday';

    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
    });
  };

  return (
    <div className="px-4 sm:px-6 md:px-8 pt-4 sm:pt-6 pb-28 md:pb-12 space-y-6 max-w-6xl mx-auto w-full transition-all">
      {/* User Greeting Header */}
      <section className="flex items-center justify-between pt-1 pb-1 border-b border-outline/50 sm:border-none">
        <div>
          <p className="text-body-sm text-muted">Welcome back</p>
          <h1 className="font-headline text-headline-sm sm:text-headline-md text-on-surface font-bold tracking-tight">
            Hi LOVELY RAJPUT
          </h1>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-full bg-primary-container border-2 border-primary/20 text-on-primary-container font-headline font-bold text-label-lg flex items-center justify-center shadow-xs">
            LR
          </div>
        </div>
      </section>

      {/* Main Responsive Grid Layout (Single Column on Mobile, 2 Columns on Desktop) */}
      <div className="lg:grid lg:grid-cols-12 lg:gap-6 lg:space-y-0 space-y-6 items-start">
        {/* Left Column: Monthly Budget Summary & Recent Expenses (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Monthly Budget Summary Card (Elevated Tall Card) */}
          <article className="bg-surface-card rounded-lg border border-outline p-6 shadow-sm min-h-[290px] flex flex-col justify-between relative overflow-hidden">
            {/* Subtle decorative background glow */}
            <div
              aria-hidden="true"
              className="absolute -right-12 -bottom-12 w-56 h-56 bg-primary-container/40 rounded-full blur-3xl pointer-events-none"
            />

            {/* Top Header & Total Spent */}
            <header className="flex items-start justify-between relative z-10">
              <div>
                <div className="flex items-center gap-1.5 text-muted mb-1">
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    account_balance_wallet
                  </span>
                  <span className="font-label text-label-sm uppercase tracking-wider font-semibold">
                    Total Spent This Month
                  </span>
                </div>
                <div className="flex items-baseline gap-2 mt-2 flex-wrap">
                  <span className="font-headline text-display-lg-mobile sm:text-display-lg text-on-surface font-extrabold tabular-nums tracking-tight">
                    {formatCurrency(totalSpent)}
                  </span>
                  <span className="text-body-md text-muted tabular-nums">
                    of {formatCurrency(monthlyBudget)} budget
                  </span>
                  <button
                    type="button"
                    onClick={handleOpenEditBudget}
                    className="inline-flex items-center gap-1 text-[12px] font-label font-semibold text-primary hover:underline px-2 py-0.5 rounded bg-primary-container/30 hover:bg-primary-container/60 transition-colors ml-1"
                    title="Edit Monthly Budget"
                    aria-label="Edit Monthly Budget"
                  >
                    <span className="material-symbols-outlined text-[14px]">edit</span>
                    <span>Edit</span>
                  </button>
                </div>
              </div>

              {/* Percentage Badge with dynamic status colors */}
              <span className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-label-sm font-label font-bold border shadow-xs ${badgeColor}`}>
                <span className="material-symbols-outlined text-[15px]">
                  {isOverBudget ? 'error' : budgetPercent >= 80 ? 'warning' : 'trending_up'}
                </span>
                {budgetPercent}%
              </span>
            </header>

            {/* Middle: Progress Bar & Financial Stats */}
            <div className="space-y-2.5 relative z-10 my-5">
              {/* Status Text: "X left" or "X over budget" */}
              <div className="flex items-center justify-between text-body-sm">
                <span className={`font-semibold tabular-nums ${
                  isOverBudget
                    ? 'text-red-600 font-bold'
                    : budgetPercent >= 80
                    ? 'text-amber-600 font-bold'
                    : 'text-emerald-700'
                }`}>
                  {remainingStatusText}
                </span>
                <span className="text-muted text-[12px] tabular-nums">
                  {budgetPercent}% spent
                </span>
              </div>

              {/* Dynamic Color Progress Bar: Green under 80%, Amber 80-100%, Red over 100% */}
              <div className="w-full h-3.5 bg-surface-subtle rounded-full overflow-hidden p-0.5 border border-outline/60">
                <div
                  role="progressbar"
                  aria-valuenow={totalSpent}
                  aria-valuemin="0"
                  aria-valuemax={monthlyBudget}
                  aria-label={`Monthly budget progress: ${budgetPercent}% spent`}
                  className={`h-full rounded-full transition-all duration-state-change ${progressBarColor}`}
                  style={{ width: `${Math.min(100, budgetPercent)}%` }}
                />
              </div>

              {/* Financial Run-rate Stat Tiles (2 Cols on mobile, 3 Cols on tablet/desktop) */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                <div className="bg-surface-subtle/70 rounded-md p-3 border border-outline/50">
                  <span className="text-[11px] text-muted font-medium block">
                    {isOverBudget ? 'Over Budget' : 'Remaining Balance'}
                  </span>
                  <span className={`font-headline text-headline-sm font-bold tabular-nums ${
                    isOverBudget
                      ? 'text-red-600'
                      : budgetPercent >= 80
                      ? 'text-amber-600'
                      : 'text-primary'
                  }`}>
                    {formatCurrency(isOverBudget ? totalSpent - monthlyBudget : remainingAmount)}
                  </span>
                  <span className="text-[10px] text-muted block mt-0.5">
                    {isOverBudget ? 'budget exceeded' : `${daysLeft} days left in cycle`}
                  </span>
                </div>

                <div className="bg-surface-subtle/70 rounded-md p-3 border border-outline/50">
                  <span className="text-[11px] text-muted font-medium block">
                    Daily Safe Spend
                  </span>
                  <span className="font-headline text-headline-sm text-on-surface font-bold tabular-nums">
                    {formatCurrency(dailySafeSpend)}
                  </span>
                  <span className="text-[10px] text-muted block mt-0.5">
                    to maintain target
                  </span>
                </div>

                <div className="bg-surface-subtle/70 rounded-md p-3 border border-outline/50 col-span-2 sm:col-span-1">
                  <span className="text-[11px] text-muted font-medium block">
                    Average / Day
                  </span>
                  <span className="font-headline text-headline-sm text-on-surface font-bold tabular-nums">
                    {formatCurrency(dailyAvg)}
                  </span>
                  <span className="text-[10px] text-muted block mt-0.5">
                    actual burn rate
                  </span>
                </div>
              </div>
            </div>

            {/* Card Footer Note */}
            <footer className="pt-3 border-t border-outline/60 flex items-center justify-between text-body-sm relative z-10 text-muted">
              <span className="inline-flex items-center gap-1.5 text-[12px] sm:text-body-sm font-medium">
                <span className={`material-symbols-outlined text-[16px] ${
                  isOverBudget ? 'text-red-600' : budgetPercent >= 80 ? 'text-amber-600' : 'text-primary'
                }`}>
                  {isOverBudget ? 'warning' : budgetPercent >= 80 ? 'info' : 'check_circle'}
                </span>
                <span className={isOverBudget ? 'text-red-600 font-semibold' : ''}>
                  {remainingStatusText}
                </span>
              </span>
              <button
                type="button"
                onClick={handleOpenEditBudget}
                className="text-xs sm:text-label-sm font-semibold text-primary hover:underline flex items-center gap-0.5"
              >
                <span>Change budget</span>
              </button>
            </footer>
          </article>

          {/* Recent Expenses List Section */}
          <section className="space-y-3">
            <div className="flex items-center justify-between px-0.5">
              <h2 className="font-headline text-title-md text-on-surface font-bold">
                Recent expenses
              </h2>
              <Link
                to="/expenses"
                className="text-label-sm font-label text-primary hover:underline font-semibold flex items-center gap-0.5"
              >
                <span>View all</span>
                <span className="material-symbols-outlined text-[16px]">
                  arrow_forward
                </span>
              </Link>
            </div>

            {recentExpenses.length === 0 ? (
              <EmptyState
                title="No recent expenses"
                message="No expenses recorded for this month yet."
                actionLabel="Add Expense"
                actionTo="/expenses/new"
              />
            ) : (
              <div className="bg-surface-card rounded-lg border border-outline divide-y divide-outline shadow-sm overflow-hidden">
                {recentExpenses.map((expense) => {
                  const category = categories.find((c) => c.id === expense.categoryId);
                  return (
                    <ExpenseListItem
                      key={expense.id}
                      expense={expense}
                      category={category}
                      variant="dashboard"
                      dateLabel={getDateLabel(expense.date)}
                      onClick={() => navigate(`/expenses/edit/${expense.id}`)}
                    />
                  );
                })}
              </div>
            )}
          </section>
        </div>

        {/* Right Column: Spending by Category Donut Chart & Legend (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-6">
          <article className="bg-surface-card rounded-lg border border-outline p-5 sm:p-6 shadow-sm space-y-4">
            <header className="flex items-center justify-between">
              <div>
                <h2 className="font-headline text-title-md text-on-surface font-bold">
                  Spending by Category
                </h2>
                <p className="text-body-sm text-muted">
                  {categoryBreakdown.length} key budget categories
                </p>
              </div>
              <Link
                to="/reports"
                className="text-label-sm font-label text-primary hover:underline font-semibold flex items-center gap-0.5"
              >
                <span>Details</span>
                <span className="material-symbols-outlined text-[14px]">
                  arrow_forward
                </span>
              </Link>
            </header>

            {categoryBreakdown.length === 0 ? (
              <div className="py-8 text-center text-muted">
                <span className="material-symbols-outlined text-[36px]">
                  pie_chart
                </span>
                <p className="text-body-sm mt-1">No category spending recorded yet.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Plain SVG Donut Visualization */}
                <div className="relative flex items-center justify-center py-2">
                  <svg
                    className="w-44 h-44 transform -rotate-90"
                    viewBox="0 0 160 160"
                    aria-label={`Donut chart showing expense distribution: ${categoryBreakdown
                      .map((c) => `${c.name} ${Math.round(c.percent)}%`)
                      .join(', ')}`}
                  >
                    {/* Background Track Ring */}
                    <circle
                      cx="80"
                      cy="80"
                      r={radius}
                      stroke="#F1F5F9"
                      strokeWidth="18"
                      fill="transparent"
                    />

                    {/* Slices drawn with SVG stroke-dasharray and stroke-dashoffset */}
                    {categoryBreakdown.map((cat) => {
                      const dashLength = (cat.percent / 100) * circumference;
                      const offset = -(cumulativePercent / 100) * circumference;
                      cumulativePercent += cat.percent;

                      return (
                        <circle
                          key={cat.id}
                          cx="80"
                          cy="80"
                          r={radius}
                          stroke={cat.color}
                          strokeWidth="18"
                          fill="transparent"
                          strokeDasharray={`${dashLength.toFixed(2)} ${circumference.toFixed(2)}`}
                          strokeDashoffset={offset.toFixed(2)}
                          strokeLinecap="butt"
                          className="hover:opacity-90 transition-opacity"
                        />
                      );
                    })}
                  </svg>

                  {/* Center Hole Metric Badge inside Donut */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                    <span className="text-body-sm text-muted text-[11px] font-medium uppercase tracking-wider">
                      Total
                    </span>
                    <span className="font-headline font-bold text-headline-sm text-on-surface tabular-nums">
                      ₹{(totalSpent / 1000).toFixed(1)}k
                    </span>
                    <span className="text-label-sm text-primary font-medium text-[10px]">
                      {categoryBreakdown.length} Sectors
                    </span>
                  </div>
                </div>

                {/* Category Legend with Amounts & Percentages */}
                <ul
                  className="space-y-2 text-body-sm pt-2 border-t border-outline/50"
                  aria-label="Category spending breakdown list"
                >
                  {categoryBreakdown.map((cat, idx) => {
                    const isLast = idx === categoryBreakdown.length - 1;
                    return (
                      <li
                        key={cat.id}
                        className={`flex items-center justify-between py-1.5 ${
                          !isLast ? 'border-b border-outline/40' : ''
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className="w-3 h-3 rounded-full shrink-0"
                            style={{ backgroundColor: cat.color }}
                          />
                          <span className="text-on-surface font-medium text-body-sm">
                            {cat.name}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="font-label text-label-sm text-on-surface tabular-nums font-semibold">
                            {formatCurrency(cat.amount)}
                          </span>
                          <span className="text-muted text-[11px] ml-1.5">
                            ({Math.round(cat.percent)}%)
                          </span>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
          </article>
        </div>
      </div>

      {/* Floating Add Expense Button */}
      <AddExpenseFab to="/expenses/new" />

      {/* Set Monthly Budget Modal Dialog */}
      {isEditingBudget && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="budget-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setIsEditingBudget(false)}
        >
          <div
            className="bg-surface-card border border-outline rounded-xl p-5 sm:p-6 shadow-xl max-w-sm w-full space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-primary-container text-on-primary-container flex items-center justify-center flex-shrink-0">
                  <span className="material-symbols-outlined text-[20px]">
                    account_balance_wallet
                  </span>
                </div>
                <h3
                  id="budget-dialog-title"
                  className="font-headline font-bold text-title-md text-on-surface"
                >
                  Set Monthly Budget
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsEditingBudget(false)}
                aria-label="Close"
                className="w-8 h-8 rounded-full flex items-center justify-center text-muted hover:text-on-surface hover:bg-surface-subtle transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            {budgetError && (
              <div
                role="alert"
                className="bg-red-50 border border-red-200 text-red-700 rounded-md p-2.5 text-body-sm flex items-center gap-2 shadow-xs"
              >
                <span className="material-symbols-outlined text-[16px] flex-shrink-0">
                  error
                </span>
                <span>{budgetError}</span>
              </div>
            )}

            <form onSubmit={handleSaveBudget} className="space-y-4">
              <div>
                <label
                  htmlFor="monthly-budget-input"
                  className="block font-label text-label-sm text-on-surface font-semibold mb-1.5"
                >
                  Monthly Budget Amount (₹)
                </label>
                <div className="relative flex items-center">
                  <span className="absolute left-3.5 text-muted font-bold text-headline-sm select-none">
                    ₹
                  </span>
                  <input
                    type="number"
                    id="monthly-budget-input"
                    autoFocus
                    inputMode="decimal"
                    step="any"
                    min="1"
                    placeholder="20000"
                    value={budgetValue}
                    onChange={(e) => {
                      setBudgetValue(e.target.value);
                      if (budgetError) setBudgetError('');
                    }}
                    className="w-full bg-surface-subtle border border-outline rounded-DEFAULT pl-9 pr-3.5 py-2.5 text-headline-sm text-on-surface font-bold tabular-nums focus:bg-surface-card focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none transition-all"
                  />
                </div>
                <p className="text-[12px] text-muted mt-1.5">
                  Must be a number above 0. Current spend this month is{' '}
                  <strong className="text-on-surface">{formatCurrency(totalSpent)}</strong>.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-outline/50">
                <button
                  type="button"
                  onClick={() => setIsEditingBudget(false)}
                  className="px-4 py-2 rounded-md border border-outline text-on-surface hover:bg-surface-subtle font-label text-label-sm font-semibold transition-colors focus:outline-none"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-md bg-primary text-white hover:opacity-95 font-label text-label-sm font-bold shadow-xs transition-all focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-1"
                >
                  Save Budget
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
