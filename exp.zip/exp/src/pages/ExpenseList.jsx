import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { categories, formatCurrency } from '../data/mockData';
import { getExpenses, deleteExpense } from '../data/storage';
import ExpenseListItem from '../components/ExpenseListItem';
import DateGroupSection from '../components/DateGroupSection';
import EmptyState from '../components/EmptyState';
import AddExpenseFab from '../components/AddExpenseFab';

export default function ExpenseList() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState('all');

  // Maintain reactive expenses in state so deletes update UI without reload
  const [expenses, setExpenses] = useState(() => getExpenses());

  // Pending item for delete confirmation dialog
  const [expenseToDelete, setExpenseToDelete] = useState(null);

  const handleDeleteConfirm = () => {
    if (!expenseToDelete) return;
    deleteExpense(expenseToDelete.id);
    setExpenses((prev) => prev.filter((item) => item.id !== expenseToDelete.id));
    setExpenseToDelete(null);
  };

  const hasExpenses = expenses && expenses.length > 0;

  // RFC 4180 compliant CSV escaping (escapes quotes as "" and wraps values with commas/quotes/newlines)
  const escapeCSVField = (field) => {
    if (field === null || field === undefined) return '';
    const str = String(field);
    if (str.includes('"') || str.includes(',') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  // Export CSV handler downloading expenses.csv from getExpenses()
  const handleExportCSV = () => {
    const dataToExport = getExpenses();
    if (!dataToExport || dataToExport.length === 0) return;

    // Required columns: date, category, amount, note, payment Method
    const headers = ['date', 'category', 'amount', 'note', 'payment Method'];

    const rows = dataToExport.map((expense) => {
      const categoryObj = categories.find((c) => c.id === expense.categoryId);
      const categoryName = categoryObj ? categoryObj.name : (expense.categoryId || '');
      const paymentMethod = expense.paymentMethod || expense.payment_method || '';

      return [
        escapeCSVField(expense.date),
        escapeCSVField(categoryName),
        escapeCSVField(expense.amount),
        escapeCSVField(expense.note),
        escapeCSVField(paymentMethod),
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'expenses.csv');
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Filter expenses by search query (matches note) and selected category
  const filteredExpenses = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return expenses.filter((item) => {
      // Category filter
      const matchesCategory =
        selectedCategoryId === 'all' || item.categoryId === selectedCategoryId;

      // Note search filter (case-insensitive)
      const noteText = (item.note || '').toLowerCase();
      const matchesSearch = !query || noteText.includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [expenses, searchQuery, selectedCategoryId]);

  // Group filtered expenses by date
  const groupedExpenses = useMemo(() => {
    // Determine today and yesterday in local time
    const now = new Date();
    const todayY = now.getFullYear();
    const todayM = String(now.getMonth() + 1).padStart(2, '0');
    const todayD = String(now.getDate()).padStart(2, '0');
    const todayStr = `${todayY}-${todayM}-${todayD}`;

    const yesterdayDate = new Date(now);
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yY = yesterdayDate.getFullYear();
    const yM = String(yesterdayDate.getMonth() + 1).padStart(2, '0');
    const yD = String(yesterdayDate.getDate()).padStart(2, '0');
    const yesterdayStr = `${yY}-${yM}-${yD}`;

    // Map by date
    const groups = {};

    // Sort descending by date, then createdAt
    const sorted = [...filteredExpenses].sort((a, b) => {
      if (b.date !== a.date) return (b.date || '').localeCompare(a.date || '');
      return (b.createdAt || '').localeCompare(a.createdAt || '');
    });

    sorted.forEach((item) => {
      const dateKey = item.date || todayStr;
      if (!groups[dateKey]) {
        const itemDate = new Date(dateKey + 'T00:00:00');
        const isToday = dateKey === todayStr;
        const isYesterday = dateKey === yesterdayStr;

        let label = '';
        let weekday = '';

        if (isToday) {
          label = 'Today';
          weekday = `(${itemDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })})`;
        } else if (isYesterday) {
          label = 'Yesterday';
          weekday = `(${itemDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })})`;
        } else {
          label = itemDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
          weekday = `(${itemDate.toLocaleDateString('en-IN', { weekday: 'long' })})`;
        }

        groups[dateKey] = {
          dateKey,
          label,
          weekday,
          isToday,
          items: [],
          subtotal: 0,
        };
      }

      groups[dateKey].items.push(item);
      groups[dateKey].subtotal += Number(item.amount) || 0;
    });

    return Object.values(groups);
  }, [filteredExpenses]);

  // Selected category name for empty state messages
  const selectedCategoryObj = categories.find((c) => c.id === selectedCategoryId);
  const selectedCategoryName = selectedCategoryObj ? selectedCategoryObj.name : 'All';

  return (
    <div className="flex flex-col min-h-full">
      {/* Sticky Search & Category Filter Sub-Header (Responsive on md+) */}
      <div className="sticky top-0 z-20 bg-surface/95 backdrop-blur-sm border-b border-outline/70 px-4 sm:px-6 md:px-8 pt-3 pb-3">
        <div className="max-w-6xl mx-auto w-full md:flex md:items-center md:gap-4 md:space-y-0 space-y-3">
          {/* Search Bar + Export CSV Action */}
          <div className="flex items-center gap-2.5 w-full md:w-auto flex-shrink-0">
            <div className="relative flex items-center flex-1 md:w-72 lg:w-80">
              <div className="absolute left-3.5 text-muted pointer-events-none flex items-center">
                <span className="material-symbols-outlined text-[20px]">
                  search
                </span>
              </div>
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search expenses by note..."
                aria-label="Search expenses by note"
                className="w-full bg-surface-card border border-outline rounded-DEFAULT pl-10 pr-9 py-2 text-body-md text-on-surface font-body placeholder:text-muted focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary shadow-xs transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  aria-label="Clear search"
                  className="absolute right-2.5 text-muted hover:text-on-surface flex items-center focus:outline-none"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    close
                  </span>
                </button>
              )}
            </div>

            {/* Export CSV Button (Disabled when no expenses) */}
            <button
              type="button"
              onClick={handleExportCSV}
              disabled={!hasExpenses}
              aria-label="Export all expenses to CSV"
              title={hasExpenses ? 'Download expenses.csv' : 'No expenses to export'}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-DEFAULT font-label text-label-sm font-semibold border shadow-xs transition-all flex-shrink-0 focus:outline-none focus:ring-1 focus:ring-primary ${
                hasExpenses
                  ? 'bg-surface-card border-outline text-on-surface hover:bg-surface-subtle hover:border-outline-strong active:scale-95'
                  : 'bg-surface-subtle border-outline/40 text-muted/50 cursor-not-allowed opacity-60'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">
                download
              </span>
              <span className="hidden sm:inline">Export CSV</span>
              <span className="sm:hidden">CSV</span>
            </button>
          </div>

          {/* Filter Chips by Category (Horizontal Scrollable) */}
          <div
            role="tablist"
            aria-label="Category Filters"
            className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5 flex-1"
          >
            {/* All Chip */}
            <button
              type="button"
              role="tab"
              aria-selected={selectedCategoryId === 'all'}
              onClick={() => setSelectedCategoryId('all')}
              className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full font-label text-label-sm shadow-xs shrink-0 transition-colors focus:outline-none ${
                selectedCategoryId === 'all'
                  ? 'bg-primary text-white font-semibold'
                  : 'bg-surface-card border border-outline text-on-surface hover:bg-surface-subtle font-medium'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">
                clear_all
              </span>
              <span>All</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums ${
                  selectedCategoryId === 'all'
                    ? 'bg-white/25 text-white'
                    : 'bg-surface-subtle text-muted'
                }`}
              >
                {expenses.length}
              </span>
            </button>

            {/* Individual Category Chips */}
            {categories.map((cat) => {
              const isSelected = selectedCategoryId === cat.id;
              const count = expenses.filter((e) => e.categoryId === cat.id).length;

              return (
                <button
                  key={cat.id}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => setSelectedCategoryId(cat.id)}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full font-label text-label-sm shadow-xs shrink-0 transition-colors focus:outline-none ${
                    isSelected
                      ? 'bg-primary text-white font-semibold'
                      : 'bg-surface-card border border-outline text-on-surface hover:bg-surface-subtle font-medium'
                  }`}
                >
                  {!isSelected && (
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                  )}
                  <span>{cat.name}</span>
                  {count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums ${
                        isSelected
                          ? 'bg-white/25 text-white'
                          : 'bg-surface-subtle text-muted'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Grouped Expenses List */}
      <main className="flex-1 px-4 sm:px-6 md:px-8 pt-4 pb-28 md:pb-12 space-y-6 max-w-6xl mx-auto w-full">
        {groupedExpenses.length === 0 ? (
          <EmptyState
            title={expenses.length === 0 ? 'No expenses yet' : 'No expenses found'}
            message={
              expenses.length === 0
                ? "You haven't recorded any expenses yet."
                : searchQuery && selectedCategoryId !== 'all'
                ? `No ${selectedCategoryName} expenses match "${searchQuery}".`
                : searchQuery
                ? `No expenses match "${searchQuery}".`
                : `No expenses found in ${selectedCategoryName}.`
            }
            icon={expenses.length === 0 ? 'receipt_long' : 'search_off'}
            actionLabel={expenses.length === 0 ? 'Add Expense' : 'Reset filters'}
            actionTo={expenses.length === 0 ? '/expenses/new' : undefined}
            onAction={
              expenses.length === 0
                ? undefined
                : () => {
                    setSearchQuery('');
                    setSelectedCategoryId('all');
                  }
            }
          />
        ) : (
          groupedExpenses.map((group) => (
            <DateGroupSection
              key={group.dateKey}
              date={group.dateKey}
              label={group.label}
              weekday={group.weekday}
              subtotal={group.subtotal}
              isToday={group.isToday}
            >
              {group.items.map((expense) => {
                const category = categories.find((c) => c.id === expense.categoryId);
                return (
                  <ExpenseListItem
                    key={expense.id}
                    expense={expense}
                    category={category}
                    variant="list"
                    onClick={() => navigate(`/expenses/edit/${expense.id}`)}
                    onDelete={(exp) => setExpenseToDelete(exp)}
                  />
                );
              })}
            </DateGroupSection>
          ))
        )}
      </main>

      {/* Floating Add Expense Button */}
      <AddExpenseFab to="/expenses/new" />

      {/* Delete Confirmation Modal Dialog */}
      {expenseToDelete && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setExpenseToDelete(null)}
        >
          <div
            className="bg-surface-card border border-outline rounded-xl p-5 sm:p-6 shadow-xl max-w-sm w-full space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-[22px]">
                  warning
                </span>
              </div>
              <div>
                <h3
                  id="delete-dialog-title"
                  className="font-headline font-bold text-title-md text-on-surface"
                >
                  Delete Expense?
                </h3>
                <p className="text-body-sm text-muted">
                  This action cannot be undone.
                </p>
              </div>
            </div>

            {/* Expense details summary card */}
            <div className="bg-surface-subtle border border-outline/60 rounded-md p-3.5 space-y-1.5">
              <div className="flex items-center justify-between text-body-sm">
                <span className="text-muted">Note:</span>
                <span className="font-semibold text-on-surface truncate max-w-[180px]">
                  {expenseToDelete.note && expenseToDelete.note.trim()
                    ? expenseToDelete.note
                    : (categories.find((c) => c.id === expenseToDelete.categoryId)?.name || 'Expense')}
                </span>
              </div>
              <div className="flex items-center justify-between text-body-sm">
                <span className="text-muted">Amount:</span>
                <span className="font-bold text-on-surface tabular-nums">
                  {formatCurrency(expenseToDelete.amount)}
                </span>
              </div>
              <div className="flex items-center justify-between text-body-sm">
                <span className="text-muted">Date:</span>
                <span className="text-on-surface">
                  {expenseToDelete.date}
                </span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setExpenseToDelete(null)}
                className="px-4 py-2 rounded-md border border-outline text-on-surface hover:bg-surface-subtle font-label text-label-sm font-semibold transition-colors focus:outline-none"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                className="px-4 py-2 rounded-md bg-red-600 text-white hover:bg-red-700 font-label text-label-sm font-semibold shadow-xs transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-1"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
