import React, { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  categories,
  categoryTints,
  iconByCategoryId,
  formatCurrency,
} from '../data/mockData';
import { getExpenses, getBudget } from '../data/storage';
import MonthSelector from '../components/MonthSelector';
import AddExpenseFab from '../components/AddExpenseFab';
import EmptyState from '../components/EmptyState';

export default function Reports() {
  const [searchParams, setSearchParams] = useSearchParams();

  // Load live expenses directly from storage layer
  const allExpenses = getExpenses();

  // Dynamically determine current, latest, and earliest available months from data
  const now = new Date();
  const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const expenseMonths = allExpenses
    .map((e) => (e.date ? e.date.slice(0, 7) : ''))
    .filter(Boolean);

  const latestMonth = expenseMonths.length > 0
    ? [currentMonthKey, ...expenseMonths].sort().reverse()[0]
    : currentMonthKey;

  const earliestMonth = expenseMonths.length > 0
    ? [...expenseMonths].sort()[0]
    : '2026-06';

  const selectedMonth = searchParams.get('month') || latestMonth;

  const handleMonthChange = (newMonth) => {
    setSearchParams({ month: newMonth });
  };

  const canGoNext = selectedMonth < latestMonth;
  const canGoPrev = selectedMonth > earliestMonth;

  // 1. Current month expenses & category totals calculated from live storage
  const { monthExpenses, totalSpent, categoryBreakdown, topCategory, dailyAvg } =
    useMemo(() => {
      const expensesInMonth = allExpenses.filter(
        (e) => e.date && e.date.startsWith(selectedMonth)
      );

      const total = expensesInMonth.reduce(
        (sum, item) => sum + (Number(item.amount) || 0),
        0
      );

      const breakdown = categories
        .map((cat) => {
          const catExpenses = expensesInMonth.filter(
            (e) => e.categoryId === cat.id
          );
          const amount = catExpenses.reduce(
            (sum, e) => sum + (Number(e.amount) || 0),
            0
          );
          const percent = total > 0 ? (amount / total) * 100 : 0;
          return {
            ...cat,
            amount,
            percent,
            count: catExpenses.length,
          };
        })
        .filter((cat) => cat.amount > 0)
        .sort((a, b) => b.amount - a.amount);

      const top = breakdown[0] || null;

      // Days elapsed calculation for daily average
      const [y, m] = selectedMonth.split('-').map(Number);
      const daysInMonth = new Date(y, m, 0).getDate();
      const isCurrentMonth = selectedMonth === latestMonth;
      const daysCount = isCurrentMonth
        ? Math.min(now.getDate(), daysInMonth)
        : daysInMonth;

      const avg = top && daysCount > 0 ? Math.round(top.amount / daysCount) : 0;

      return {
        monthExpenses: expensesInMonth,
        totalSpent: total,
        categoryBreakdown: breakdown,
        topCategory: top,
        dailyAvg: avg,
      };
    }, [selectedMonth, allExpenses, latestMonth]);

  // 2. 6-Month Trend Data ending at the selected month calculated from live storage
  const { sixMonths, sixMonthsAvg, comparisonText, isTrendingDown } =
    useMemo(() => {
      const [selYear, selMonth] = selectedMonth.split('-').map(Number);
      const monthsList = [];

      for (let i = 5; i >= 0; i--) {
        const d = new Date(selYear, selMonth - 1 - i, 1);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const key = `${y}-${m}`;
        const monthShort = d.toLocaleDateString('en-IN', { month: 'short' });
        const monthFull = d.toLocaleDateString('en-IN', {
          month: 'long',
          year: 'numeric',
        });

        const total = allExpenses
          .filter((e) => e.date && e.date.startsWith(key))
          .reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

        monthsList.push({
          key,
          monthShort,
          monthFull,
          total,
        });
      }

      // Compute exact 6-month average (Rule E2)
      const sum = monthsList.reduce((acc, item) => acc + item.total, 0);
      const avg = monthsList.length > 0 ? sum / monthsList.length : 0;

      // Comparison vs previous month
      const currentMonthTotal = monthsList[5].total;
      const prevMonthTotal = monthsList[4]?.total || 0;
      let compText = '';
      let isDown = false;

      if (prevMonthTotal > 0) {
        const diffPercent = Math.round(
          Math.abs((currentMonthTotal - prevMonthTotal) / prevMonthTotal) * 100
        );
        isDown = currentMonthTotal < prevMonthTotal;
        compText = `${diffPercent}% ${isDown ? 'less' : 'more'} than ${monthsList[4].monthShort}`;
      } else {
        compText = 'First recorded month';
      }

      return {
        sixMonths: monthsList,
        sixMonthsAvg: avg,
        comparisonText: compText,
        isTrendingDown: isDown,
      };
    }, [selectedMonth, allExpenses]);

  // Chart scaling calculations
  const maxVal = Math.max(...sixMonths.map((m) => m.total), 20000) * 1.05;
  const baselineY = 125;
  const maxBarHeight = 100;

  return (
    <div className="flex-1 px-4 sm:px-6 md:px-8 pt-4 sm:pt-6 pb-28 md:pb-12 space-y-6 max-w-6xl mx-auto w-full transition-all">
      {/* Month Selector Bar (Centered width) */}
      <div className="max-w-md mx-auto w-full">
        <MonthSelector
          month={selectedMonth}
          onChange={handleMonthChange}
          canGoNext={canGoNext}
          canGoPrev={canGoPrev}
        />
      </div>

      {monthExpenses.length === 0 ? (
        <EmptyState
          title="No expenses for this month"
          message="There are no expenses recorded for the selected month."
          icon="calendar_today"
          actionLabel="Go to Current Month"
          onAction={() => handleMonthChange(latestMonth)}
        />
      ) : (
        <>
          {/* Main Content Grid (1 Column on Mobile, 2 Columns on Desktop) */}
          <div className="lg:grid lg:grid-cols-12 lg:gap-6 space-y-6 lg:space-y-0 items-start">
            {/* Left Column: 6-Month Spending Trend Bar Chart Card (7 cols on lg) */}
            <div className="lg:col-span-7 space-y-6">
              <article className="bg-surface-card rounded-lg border border-outline p-5 sm:p-6 shadow-sm space-y-4">
                <header className="flex items-center justify-between">
                  <div>
                    <h2 className="font-headline text-title-md text-on-surface font-bold">
                      Spending Trend
                    </h2>
                    <p className="text-body-sm text-muted">
                      Last 6 Months ({sixMonths[0]?.monthShort} - {sixMonths[5]?.monthShort})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-label-sm text-muted">Avg:</span>
                    <span className="font-label text-label-md text-on-surface font-bold tabular-nums ml-1">
                      ₹{(sixMonthsAvg / 1000).toFixed(1)}k
                    </span>
                  </div>
                </header>

                {/* SVG Bar Chart */}
                <div className="pt-2 flex justify-center">
                  <svg
                    className="w-full max-w-[440px] h-48 overflow-visible"
                    viewBox="0 0 320 160"
                    aria-label={`Bar chart showing spending over the last 6 months: ${sixMonths
                      .map((m) => `${m.monthShort} ₹${m.total.toLocaleString('en-IN')}`)
                      .join(', ')}`}
                  >
                    {/* Horizontal Dashed Grid Lines */}
                    <line
                      x1="25"
                      y1="20"
                      x2="310"
                      y2="20"
                      stroke="#F1F5F9"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                    <line
                      x1="25"
                      y1="55"
                      x2="310"
                      y2="55"
                      stroke="#F1F5F9"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                    <line
                      x1="25"
                      y1="90"
                      x2="310"
                      y2="90"
                      stroke="#F1F5F9"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />

                    {/* Solid Baseline */}
                    <line
                      x1="25"
                      y1={baselineY}
                      x2="310"
                      y2={baselineY}
                      stroke="#CBD5E1"
                      strokeWidth="1"
                    />

                    {/* Y-Axis Value Labels */}
                    <text
                      x="2"
                      y="24"
                      fill="#94A3B8"
                      fontSize="9"
                      fontFamily="'Instrument Sans', sans-serif"
                    >
                      20k
                    </text>
                    <text
                      x="2"
                      y="59"
                      fill="#94A3B8"
                      fontSize="9"
                      fontFamily="'Instrument Sans', sans-serif"
                    >
                      15k
                    </text>
                    <text
                      x="2"
                      y="94"
                      fill="#94A3B8"
                      fontSize="9"
                      fontFamily="'Instrument Sans', sans-serif"
                    >
                      10k
                    </text>
                    <text
                      x="2"
                      y="129"
                      fill="#94A3B8"
                      fontSize="9"
                      fontFamily="'Instrument Sans', sans-serif"
                    >
                      0
                    </text>

                    {/* 6 Monthly Bars (28px wide with 4px radius) */}
                    {sixMonths.map((item, idx) => {
                      const xPos = 38 + idx * 47;
                      const barHeight = Math.max(
                        6,
                        Math.round((item.total / maxVal) * maxBarHeight)
                      );
                      const yPos = baselineY - barHeight;
                      const isSelected = item.key === selectedMonth;

                      return (
                        <g
                          key={item.key}
                          onClick={() => handleMonthChange(item.key)}
                          className="cursor-pointer"
                        >
                          {/* Bar Rectangle */}
                          <rect
                            x={xPos}
                            y={yPos}
                            width="28"
                            height={barHeight}
                            rx="4"
                            fill={isSelected ? '#059669' : '#CBD5E1'}
                            className={`transition-colors duration-150 ${
                              !isSelected ? 'hover:fill-primary/60' : ''
                            }`}
                          />

                          {/* Value Badge above selected bar */}
                          {isSelected && (
                            <text
                              x={xPos + 14}
                              y={yPos - 8}
                              textAnchor="middle"
                              fill="#059669"
                              fontWeight="700"
                              fontSize="9"
                              fontFamily="'Red Hat Text', sans-serif"
                            >
                              ₹{(item.total / 1000).toFixed(1)}k
                            </text>
                          )}

                          {/* Month Label beneath baseline */}
                          <text
                            x={xPos + 14}
                            y="142"
                            textAnchor="middle"
                            fill={isSelected ? '#059669' : '#64748B'}
                            fontWeight={isSelected ? '700' : '500'}
                            fontSize="10"
                            fontFamily="'Red Hat Text', sans-serif"
                          >
                            {item.monthShort}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                {/* Footer Summary: Budget Ceiling & Trend vs Previous Month */}
                <div className="flex items-center justify-between text-body-sm pt-2 border-t border-outline/60 text-muted">
                  <span>
                    Budget Ceiling:{' '}
                    <strong className="text-on-surface">{formatCurrency(getBudget())}</strong>
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 font-medium ${
                      isTrendingDown ? 'text-primary' : 'text-amber-600'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[15px]">
                      {isTrendingDown ? 'trending_down' : 'trending_up'}
                    </span>
                    <span>{comparisonText}</span>
                  </span>
                </div>
              </article>
            </div>

            {/* Right Column: Top Category Highlight Card (5 cols on lg) */}
            <div className="lg:col-span-5 space-y-6">
              {topCategory && (
                <article
                  className="bg-surface-card rounded-lg border-2 p-5 sm:p-6 shadow-sm relative overflow-hidden"
                  style={{ borderColor: `${topCategory.color}4D` }}
                >
                  {/* Subtle background glow */}
                  <div
                    aria-hidden="true"
                    className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full blur-xl pointer-events-none"
                    style={{ backgroundColor: `${topCategory.color}26` }}
                  />

                  <div className="flex items-start justify-between relative z-10">
                    <div className="flex items-center gap-3.5">
                      {/* 48px Category Icon Tile */}
                      <div
                        className={`w-12 h-12 rounded-xl flex items-center justify-center border shadow-xs ${
                          categoryTints[topCategory.id]?.bg || 'bg-amber-50'
                        } ${categoryTints[topCategory.id]?.border || 'border-amber-200'}`}
                        style={{ color: topCategory.color }}
                      >
                        <span className="material-symbols-outlined text-[26px]">
                          {iconByCategoryId[topCategory.id] || 'restaurant'}
                        </span>
                      </div>

                      <div>
                        <span
                          className="font-label text-[11px] uppercase font-bold tracking-wider block"
                          style={{ color: topCategory.color }}
                        >
                          Top Spending Category
                        </span>
                        <h2 className="font-headline text-title-md text-on-surface font-bold">
                          {topCategory.name}
                        </h2>
                      </div>
                    </div>

                    {/* Percentage Pill */}
                    <span
                      className={`inline-flex items-center px-2.5 py-1 rounded-full font-label text-[11px] font-bold ${
                        categoryTints[topCategory.id]?.bg || 'bg-amber-100'
                      } ${categoryTints[topCategory.id]?.text || 'text-amber-900'}`}
                    >
                      {topCategory.percent.toFixed(1)}%
                    </span>
                  </div>

                  {/* Total and Average per Day Footer */}
                  <div className="mt-5 pt-4 border-t border-outline/60 flex items-center justify-between text-body-sm relative z-10">
                    <div>
                      <span className="text-muted text-[12px] block">
                        Total spent on {topCategory.name}:
                      </span>
                      <div className="font-headline text-headline-sm text-on-surface font-bold tabular-nums">
                        {formatCurrency(topCategory.amount)}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-muted text-[12px] block">
                        Avg per day:
                      </span>
                      <div className="font-label text-label-md text-muted tabular-nums font-semibold">
                        {formatCurrency(dailyAvg)} / day
                      </div>
                    </div>
                  </div>
                </article>
              )}
            </div>

            {/* Category Breakdown with Percentages List (12 cols on lg) */}
            <div className="lg:col-span-12 space-y-3">
              <div className="flex items-center justify-between px-0.5">
                <h2 className="font-headline text-title-md text-on-surface font-bold">
                  Category Breakdown
                </h2>
                <span className="text-body-sm text-muted">
                  Total: {formatCurrency(totalSpent)}
                </span>
              </div>

              <ul className="bg-surface-card rounded-lg border border-outline divide-y divide-outline shadow-sm overflow-hidden">
                {categoryBreakdown.map((cat) => {
                  const tint = categoryTints[cat.id] || {
                    bg: 'bg-emerald-50',
                    border: 'border-emerald-100',
                  };
                  const iconName = iconByCategoryId[cat.id] || 'category';

                  return (
                    <li
                      key={cat.id}
                      className="p-4 space-y-2.5 hover:bg-surface-subtle transition-colors duration-state-change"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {/* 32px Icon Circle */}
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border ${tint.bg} ${tint.border}`}
                            style={{ color: cat.color }}
                          >
                            <span className="material-symbols-outlined text-[17px]">
                              {iconName}
                            </span>
                          </div>
                          <div>
                            <span className="font-label text-label-md text-on-surface font-semibold">
                              {cat.name}
                            </span>
                            <span className="text-[11px] text-muted ml-2">
                              • {cat.count} {cat.count === 1 ? 'item' : 'items'}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className="font-label text-label-md text-on-surface font-bold tabular-nums">
                            {formatCurrency(cat.amount)}
                          </span>
                          <span
                            className="text-[11px] font-semibold ml-2"
                            style={{ color: cat.color }}
                          >
                            ({cat.percent.toFixed(1)}%)
                          </span>
                        </div>
                      </div>

                      {/* Mini Progress Bar */}
                      <div
                        role="progressbar"
                        aria-valuenow={Math.round(cat.percent)}
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-label={`${cat.name} spending proportion: ${cat.percent.toFixed(1)}%`}
                        className="w-full h-1.5 bg-surface-subtle rounded-full overflow-hidden"
                      >
                        <div
                          className="h-full rounded-full transition-all duration-state-change"
                          style={{
                            width: `${cat.percent}%`,
                            backgroundColor: cat.color,
                          }}
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </>
      )}

      {/* Floating Add Expense Button */}
      <AddExpenseFab to="/expenses/new" />
    </div>
  );
}
