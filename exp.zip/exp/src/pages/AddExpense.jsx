import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { categories, categoryTints, iconByCategoryId, formatCurrency } from '../data/mockData';
import { getExpenses, getBudget, addExpense, updateExpense } from '../data/storage';
import FormHeader from '../components/FormHeader';

// Helper for local YYYY-MM-DD
function getLocalDateString() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export default function AddExpense() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditMode = Boolean(id);

  // Look up matching expense from storage when in edit mode
  const existingExpense = useMemo(() => {
    if (!id) return null;
    const all = getExpenses();
    return all.find((e) => e.id === id) || null;
  }, [id]);

  // Form fields: pre-filled from existingExpense in edit mode, empty in add mode
  const [amount, setAmount] = useState(() =>
    existingExpense ? String(existingExpense.amount ?? '') : ''
  );
  const [categoryId, setCategoryId] = useState(() =>
    existingExpense ? existingExpense.categoryId || '' : ''
  );
  const [date, setDate] = useState(() =>
    existingExpense ? existingExpense.date || getLocalDateString() : getLocalDateString()
  );
  const [note, setNote] = useState(() =>
    existingExpense ? existingExpense.note || '' : ''
  );

  // Validation error state
  const [error, setError] = useState('');
  // Saved confirmation state
  const [isSaved, setIsSaved] = useState(false);

  // Calculate live budget remaining for current month
  const now = new Date();
  const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const monthTotal = useMemo(() => {
    return getExpenses()
      .filter((e) => e.date && e.date.startsWith(currentMonthKey))
      .reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  }, [currentMonthKey]);
  const monthlyBudget = getBudget();
  const remainingBudget = monthlyBudget - monthTotal;

  // Check if expense exists in edit mode
  useEffect(() => {
    if (isEditMode && !existingExpense) {
      setError(`Expense with ID "${id}" was not found.`);
    }
  }, [isEditMode, existingExpense, id]);

  const handleReset = () => {
    if (isEditMode && existingExpense) {
      setAmount(String(existingExpense.amount ?? ''));
      setCategoryId(existingExpense.categoryId || '');
      setDate(existingExpense.date || getLocalDateString());
      setNote(existingExpense.note || '');
    } else {
      setAmount('');
      setCategoryId('');
      setDate(getLocalDateString());
      setNote('');
    }
    setError('');
    setIsSaved(false);
  };

  const handleSave = (e) => {
    if (e) e.preventDefault();
    if (isSaved) return;

    // Validation 1: Amount must be above 0
    const numericAmount = parseFloat(amount);
    if (!amount || isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid expense amount greater than ₹0.');
      return;
    }

    // Validation 2: Category must be picked
    if (!categoryId) {
      setError('Please select a category for this expense.');
      return;
    }

    // Validation 3: Date is required
    if (!date) {
      setError('Please select a date.');
      return;
    }

    // Clear error
    setError('');

    if (isEditMode) {
      // Edit mode: update existing expense
      const changes = {
        amount: numericAmount,
        categoryId,
        date,
        note: note.trim(),
      };

      updateExpense(id, changes);

      // Show brief confirmation, then go back to the list
      setIsSaved(true);
      setTimeout(() => {
        navigate('/expenses');
      }, 650);
    } else {
      // Add mode: call addExpense with generated id and createdAt
      const newExpense = {
        id: `exp-${Date.now()}`,
        amount: numericAmount,
        categoryId,
        date,
        note: note.trim(),
        createdAt: new Date().toISOString(),
      };

      addExpense(newExpense);

      // Show brief confirmation, then navigate to /
      setIsSaved(true);
      setTimeout(() => {
        navigate('/');
      }, 650);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Sticky Contextual Top Bar with Back Arrow */}
      <FormHeader
        title={isEditMode ? 'Edit Expense' : 'Add Expense'}
        onReset={handleReset}
      />

      {/* Main Scrollable Form Body */}
      <main className="flex-1 px-4 sm:px-6 md:px-8 py-5 max-w-md sm:max-w-xl md:max-w-2xl mx-auto w-full space-y-5 pb-32">
        {/* Inline Feedback Confirmation Message */}
        {isSaved && (
          <div
            role="status"
            aria-live="polite"
            className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md p-3 text-body-sm flex items-center gap-2 shadow-xs"
          >
            <span className="material-symbols-outlined text-[20px] text-primary flex-shrink-0">
              check_circle
            </span>
            <span className="font-semibold">
              {isEditMode ? 'Updated! Taking you back to Expenses...' : 'Saved! Taking you to Dashboard...'}
            </span>
          </div>
        )}

        {/* Inline Feedback Error Message */}
        {error && !isSaved && (
          <div
            role="alert"
            className="bg-[#FEF2F2] border border-red-200 text-[#DC2626] rounded-md p-3 text-body-sm flex items-center gap-2 shadow-xs"
          >
            <span className="material-symbols-outlined text-[18px] flex-shrink-0">
              error
            </span>
            <span className="font-medium">{error}</span>
          </div>
        )}

        {/* Section 1: Hero Large Amount Input */}
        <article className="bg-surface-card rounded-lg border border-outline p-6 sm:p-7 shadow-sm text-center relative overflow-hidden">
          <label
            htmlFor="expense-amount"
            className="block font-label text-label-sm text-muted uppercase tracking-wider mb-2 font-medium"
          >
            {isEditMode ? 'Edit Expense Amount' : 'Enter Expense Amount'}
          </label>

          {/* Large Currency & Number Input */}
          <div className="inline-flex items-center justify-center gap-2 w-full py-2">
            <span className="font-headline text-[44px] sm:text-[52px] leading-none text-primary font-extrabold select-none">
              ₹
            </span>
            <input
              type="number"
              id="expense-amount"
              inputMode="decimal"
              step="any"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                if (error) setError('');
              }}
              placeholder="0"
              className="w-64 sm:w-80 text-center font-headline text-[48px] sm:text-[54px] leading-none text-on-surface font-extrabold tracking-tight bg-transparent border-0 p-0 focus:ring-0 focus:outline-none tabular-nums placeholder:text-outline-strong"
            />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-subtle text-muted text-body-sm mt-3 border border-outline/50">
            <span>Budget balance:</span>
            <strong className={`tabular-nums font-semibold ${remainingBudget < 0 ? 'text-red-600' : 'text-on-surface'}`}>
              {remainingBudget >= 0
                ? `${formatCurrency(remainingBudget)} left`
                : `${formatCurrency(Math.abs(remainingBudget))} over budget`}
            </strong>
          </div>
        </article>

        {/* Section 2: Category Selection Grid (3 cols mobile, 6 cols tablet/desktop) */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between px-0.5">
            <h2 className="font-headline text-title-md text-on-surface font-bold">
              Category
            </h2>
            <span className="text-body-sm text-muted">Select one</span>
          </div>

          <div
            role="radiogroup"
            aria-label="Select Expense Category"
            className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 sm:gap-3"
          >
            {categories.map((cat) => {
              const isSelected = categoryId === cat.id;
              const tint = categoryTints[cat.id] || {
                bg: 'bg-emerald-50',
                border: 'border-emerald-100',
              };
              const iconName = iconByCategoryId[cat.id] || 'category';

              return (
                <button
                  key={cat.id}
                  type="button"
                  role="radio"
                  aria-checked={isSelected}
                  onClick={() => {
                    setCategoryId(cat.id);
                    if (error) setError('');
                  }}
                  className={`flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-md transition-all text-center focus:outline-none ${
                    isSelected
                      ? `border-2 ${tint.bg} shadow-xs font-bold`
                      : 'bg-surface-card border border-outline hover:border-outline-strong font-medium text-on-surface'
                  }`}
                  style={isSelected ? { borderColor: cat.color } : {}}
                >
                  <div
                    className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full flex items-center justify-center mb-1 transition-colors ${
                      isSelected
                        ? 'text-white shadow-xs'
                        : `border ${tint.bg} ${tint.border}`
                    }`}
                    style={{
                      backgroundColor: isSelected ? cat.color : undefined,
                      color: !isSelected ? cat.color : '#FFFFFF',
                    }}
                  >
                    <span
                      className="material-symbols-outlined text-[20px]"
                      aria-hidden="true"
                    >
                      {iconName}
                    </span>
                  </div>
                  <span
                    className={`font-label text-[11px] sm:text-label-sm leading-tight truncate w-full ${
                      isSelected ? 'font-bold' : 'font-semibold text-on-surface'
                    }`}
                    style={isSelected ? { color: cat.color } : {}}
                  >
                    {cat.name}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Section 3: Date Picker & Note Field (Side-by-side on sm+ screens) */}
        <section className="bg-surface-card rounded-lg border border-outline p-4 sm:p-5 shadow-sm space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Date Picker Input */}
            <div>
              <label
                htmlFor="expense-date"
                className="block font-label text-label-sm text-on-surface font-semibold mb-1.5"
              >
                Date
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-muted pointer-events-none flex items-center">
                  <span className="material-symbols-outlined text-[20px]">
                    calendar_today
                  </span>
                </div>
                <input
                  type="date"
                  id="expense-date"
                  value={date}
                  onChange={(e) => {
                    setDate(e.target.value);
                    if (error) setError('');
                  }}
                  className="w-full bg-surface-subtle border border-outline rounded-DEFAULT pl-10 pr-3.5 py-2.5 text-body-md text-on-surface font-body focus:bg-surface-card focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none transition-all"
                />
              </div>
            </div>

            {/* Note / Description Field */}
            <div>
              <label
                htmlFor="expense-note"
                className="block font-label text-label-sm text-on-surface font-semibold mb-1.5"
              >
                Note <span className="text-muted font-normal text-xs">(optional)</span>
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3.5 text-muted pointer-events-none flex items-center">
                  <span className="material-symbols-outlined text-[20px]">
                    edit_note
                  </span>
                </div>
                <input
                  type="text"
                  id="expense-note"
                  placeholder="e.g. Olive Bistro dinner"
                  value={note}
                  onChange={(e) => {
                    setNote(e.target.value);
                  }}
                  className="w-full bg-surface-subtle border border-outline rounded-DEFAULT pl-10 pr-3.5 py-2.5 text-body-md text-on-surface font-body focus:bg-surface-card focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none transition-all placeholder:text-muted"
                />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Sticky Full-Width Save Button Dock */}
      <footer className="fixed bottom-0 inset-x-0 z-40 bg-surface-card/95 backdrop-blur-sm border-t border-outline px-4 sm:px-6 md:px-8 py-3.5">
        <div className="max-w-md sm:max-w-xl md:max-w-2xl mx-auto">
          <button
            type="button"
            disabled={isSaved}
            onClick={handleSave}
            className={`w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-DEFAULT text-white font-label text-label-lg font-bold shadow-md transition-all duration-state-change focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 ${
              isSaved
                ? 'bg-emerald-600 shadow-emerald-600/25 cursor-default'
                : 'bg-primary shadow-primary/25 hover:opacity-95 active:scale-[0.99]'
            }`}
          >
            <span
              className="material-symbols-outlined text-[20px]"
              aria-hidden="true"
            >
              {isSaved ? 'check' : 'check_circle'}
            </span>
            <span>
              {isSaved
                ? 'Saved!'
                : isEditMode
                ? 'Update Expense'
                : 'Save Expense'}
            </span>
          </button>
        </div>
      </footer>
    </div>
  );
}
