import { expenses as seedExpenses } from './mockData';

export const STORAGE_KEY = 'expense-tracker-data';
export const BUDGET_STORAGE_KEY = 'expense-tracker-budget';
export const DEFAULT_BUDGET = 20000;

/**
 * Gets the monthly budget limit from localStorage, defaulting to 20000.
 * @returns {number}
 */
export function getBudget() {
  if (typeof window === 'undefined') return DEFAULT_BUDGET;
  const raw = localStorage.getItem(BUDGET_STORAGE_KEY);
  if (!raw) return DEFAULT_BUDGET;
  const val = Number(raw);
  return isNaN(val) || val <= 0 ? DEFAULT_BUDGET : val;
}

/**
 * Sets the monthly budget limit in localStorage.
 * Validates that amount is a positive number > 0.
 * @param {number|string} amount
 * @returns {number} The updated budget number
 */
export function setBudget(amount) {
  const numeric = Number(amount);
  if (isNaN(numeric) || numeric <= 0) {
    throw new Error('Budget must be a valid number greater than 0');
  }
  try {
    localStorage.setItem(BUDGET_STORAGE_KEY, String(numeric));
  } catch (err) {
    console.error('Failed to write budget to localStorage:', err);
  }
  return numeric;
}

/**
 * Safely reads the expenses array from localStorage.
 * If empty or corrupted, initializes and seeds with mockData.
 * @returns {Array<object>}
 */
export function getExpenses() {
  if (typeof window === 'undefined') return [...seedExpenses];

  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    return seedStorage();
  }

  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return seedStorage();
    }
    return parsed;
  } catch (err) {
    console.error('Error parsing localStorage expenses, reseeding:', err);
    return seedStorage();
  }
}

/**
 * Seeds localStorage with the default mock expenses.
 * @returns {Array<object>}
 */
function seedStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedExpenses));
  } catch (err) {
    console.error('Failed to seed localStorage:', err);
  }
  return [...seedExpenses];
}

/**
 * Adds a new expense to localStorage.
 * Automatically generates an id and createdAt if missing.
 * @param {object} expense
 * @returns {object} The created expense
 */
export function addExpense(expense) {
  if (!expense || typeof expense !== 'object') {
    throw new Error('Invalid expense object');
  }

  const current = getExpenses();
  const id = expense.id || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `exp-${Date.now()}`);
  const createdAt = expense.createdAt || new Date().toISOString();
  const date = expense.date || new Date().toISOString().slice(0, 10);
  const amount = Number(expense.amount) || 0;

  const newExpense = {
    ...expense,
    id,
    amount,
    categoryId: expense.categoryId || 'other',
    date,
    note: expense.note || '',
    createdAt,
  };

  const updated = [newExpense, ...current];
  saveToStorage(updated);
  return newExpense;
}

/**
 * Updates an existing expense by ID.
 * @param {string} id - The ID of the expense to update
 * @param {object} changes - Object containing modified fields
 * @returns {object|null} The updated expense, or null if not found
 */
export function updateExpense(id, changes) {
  if (!id || !changes || typeof changes !== 'object') {
    throw new Error('id and changes object are required');
  }

  const current = getExpenses();
  let updatedItem = null;

  const updated = current.map((item) => {
    if (item.id === id) {
      updatedItem = {
        ...item,
        ...changes,
        ...(changes.amount !== undefined ? { amount: Number(changes.amount) || 0 } : {}),
      };
      return updatedItem;
    }
    return item;
  });

  if (updatedItem) {
    saveToStorage(updated);
  } else {
    console.warn(`Expense with id "${id}" not found.`);
  }

  return updatedItem;
}

/**
 * Deletes an expense by ID from localStorage.
 * @param {string} id - The ID of the expense to delete
 * @returns {boolean} True if deleted, false if not found
 */
export function deleteExpense(id) {
  if (!id) return false;

  const current = getExpenses();
  const exists = current.some((item) => item.id === id);
  if (!exists) {
    console.warn(`Expense with id "${id}" not found.`);
    return false;
  }

  const updated = current.filter((item) => item.id !== id);
  saveToStorage(updated);
  return true;
}

/**
 * Resets storage back to original mock data.
 * Useful for development and manual testing.
 * @returns {Array<object>}
 */
export function resetExpenses() {
  return seedStorage();
}

/**
 * Helper to persist data to localStorage
 * @param {Array<object>} data
 */
function saveToStorage(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error('Failed to write to localStorage:', err);
  }
}

// Initial auto-seed check on script load
if (typeof window !== 'undefined') {
  if (!localStorage.getItem(STORAGE_KEY)) {
    seedStorage();
  }

  // Expose storage API on window for browser console testing
  window.storage = {
    STORAGE_KEY,
    BUDGET_STORAGE_KEY,
    DEFAULT_BUDGET,
    getExpenses,
    addExpense,
    updateExpense,
    deleteExpense,
    resetExpenses,
    getBudget,
    setBudget,
  };
}
