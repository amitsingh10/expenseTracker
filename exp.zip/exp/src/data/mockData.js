// Expense Tracker Data Model & Seed Mock Data
// Conforms to Handoff Sheet Section 2

export const categories = [
  { id: 'food', name: 'Food', color: '#F59E0B' },
  { id: 'transport', name: 'Transport', color: '#3B82F6' },
  { id: 'rent', name: 'Rent', color: '#8B5CF6' },
  { id: 'entertainment', name: 'Entertainment', color: '#4F46E5' },
  { id: 'shopping', name: 'Shopping', color: '#EC4899' },
  { id: 'other', name: 'Other', color: '#10B981' },
];

export const iconByCategoryId = {
  food: 'restaurant',
  transport: 'directions_car',
  rent: 'receipt_long',
  entertainment: 'movie',
  shopping: 'shopping_bag',
  other: 'category',
};

export const categoryTints = {
  food: { bg: 'bg-amber-50', border: 'border-amber-100', text: 'text-amber-800' },
  transport: { bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-800' },
  rent: { bg: 'bg-purple-50', border: 'border-purple-100', text: 'text-purple-800' },
  entertainment: { bg: 'bg-indigo-50', border: 'border-indigo-100', text: 'text-indigo-800' },
  shopping: { bg: 'bg-pink-50', border: 'border-pink-100', text: 'text-pink-800' },
  other: { bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-800' },
};

// Formatting helpers
export function formatCurrency(amount, includeDecimals = false) {
  const numeric = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: includeDecimals ? 2 : 0,
    maximumFractionDigits: includeDecimals ? 2 : 0,
  }).format(numeric);
  return `₹${formatted}`;
}

export function formatExpenseAmount(amount, includeDecimals = false) {
  return `-₹${new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: includeDecimals ? 2 : 0,
    maximumFractionDigits: includeDecimals ? 2 : 0,
  }).format(amount || 0)}`;
}

// Model: Expense (id, amount, categoryId, date, note, createdAt)
// Calibrated to produce exactly ₹12,480 for Nov 2026 matching mockup and Handoff Section 6
export const expenses = [
  // --- November 2026 (Total: ₹12,480) ---
  {
    id: 'exp-01',
    amount: 1850,
    categoryId: 'food',
    date: '2026-11-18',
    note: 'Grocery & Organic Veggies',
    createdAt: '2026-11-18T11:20:00.000Z',
  },
  {
    id: 'exp-02',
    amount: 420,
    categoryId: 'transport',
    date: '2026-11-17',
    note: 'Metro Card & Uber Ride',
    createdAt: '2026-11-17T18:45:00.000Z',
  },
  {
    id: 'exp-03',
    amount: 2190,
    categoryId: 'shopping',
    date: '2026-11-14',
    note: 'Casual Sneakers & Socks',
    createdAt: '2026-11-14T15:15:00.000Z',
  },
  {
    id: 'exp-04',
    amount: 1203,
    categoryId: 'transport',
    date: '2026-11-12',
    note: 'Fuel petrol top-up',
    createdAt: '2026-11-12T10:00:00.000Z',
  },
  {
    id: 'exp-05',
    amount: 2518,
    categoryId: 'food',
    date: '2026-11-10',
    note: 'Dinner at Punjab Grill & sweets',
    createdAt: '2026-11-10T20:30:00.000Z',
  },
  {
    id: 'exp-06',
    amount: 2496,
    categoryId: 'rent',
    date: '2026-11-05',
    note: 'Apartment utility bills & wifi',
    createdAt: '2026-11-05T09:00:00.000Z',
  },
  {
    id: 'exp-07',
    amount: 555,
    categoryId: 'shopping',
    date: '2026-11-03',
    note: 'Bookstore novel & notebook',
    createdAt: '2026-11-03T16:00:00.000Z',
  },
  {
    id: 'exp-08',
    amount: 1248,
    categoryId: 'other',
    date: '2026-11-01',
    note: 'Balcony plants and ceramic pots',
    createdAt: '2026-11-01T14:00:00.000Z',
  },

  // --- October 2026 (Total: ₹18,100) ---
  {
    id: 'exp-09',
    amount: 12000,
    categoryId: 'rent',
    date: '2026-10-01',
    note: 'House rent partial advance',
    createdAt: '2026-10-01T09:00:00.000Z',
  },
  {
    id: 'exp-10',
    amount: 3850,
    categoryId: 'shopping',
    date: '2026-10-24',
    note: 'Diwali festive ethnic wear',
    createdAt: '2026-10-24T15:30:00.000Z',
  },
  {
    id: 'exp-11',
    amount: 1450,
    categoryId: 'food',
    date: '2026-10-18',
    note: 'Family buffet dinner',
    createdAt: '2026-10-18T20:00:00.000Z',
  },
  {
    id: 'exp-12',
    amount: 800,
    categoryId: 'transport',
    date: '2026-10-10',
    note: 'Cab rides across city',
    createdAt: '2026-10-10T12:00:00.000Z',
  },

  // --- September 2026 (Total: ₹16,900) ---
  {
    id: 'exp-13',
    amount: 11000,
    categoryId: 'rent',
    date: '2026-09-01',
    note: 'Rent payment',
    createdAt: '2026-09-01T09:00:00.000Z',
  },
  {
    id: 'exp-14',
    amount: 2900,
    categoryId: 'food',
    date: '2026-09-18',
    note: 'Monthly groceries at Nature Basket',
    createdAt: '2026-09-18T11:00:00.000Z',
  },
  {
    id: 'exp-15',
    amount: 1800,
    categoryId: 'entertainment',
    date: '2026-09-12',
    note: 'Comedy club tickets and drinks',
    createdAt: '2026-09-12T19:30:00.000Z',
  },
  {
    id: 'exp-16',
    amount: 1200,
    categoryId: 'transport',
    date: '2026-09-05',
    note: 'Monthly metro pass',
    createdAt: '2026-09-05T08:30:00.000Z',
  },

  // --- August 2026 (Total: ₹14,500) ---
  {
    id: 'exp-17',
    amount: 10000,
    categoryId: 'rent',
    date: '2026-08-01',
    note: 'Rent payment',
    createdAt: '2026-08-01T09:00:00.000Z',
  },
  {
    id: 'exp-18',
    amount: 2500,
    categoryId: 'food',
    date: '2026-08-16',
    note: 'Weekend dining out',
    createdAt: '2026-08-16T13:00:00.000Z',
  },
  {
    id: 'exp-19',
    amount: 2000,
    categoryId: 'shopping',
    date: '2026-08-09',
    note: 'Monsoon footwear and umbrella',
    createdAt: '2026-08-09T16:00:00.000Z',
  },

  // --- July 2026 (Total: ₹15,800) ---
  {
    id: 'exp-20',
    amount: 11000,
    categoryId: 'rent',
    date: '2026-07-01',
    note: 'Rent payment',
    createdAt: '2026-07-01T09:00:00.000Z',
  },
  {
    id: 'exp-21',
    amount: 2800,
    categoryId: 'food',
    date: '2026-07-15',
    note: 'Weekly provisions & fruits',
    createdAt: '2026-07-15T11:00:00.000Z',
  },
  {
    id: 'exp-22',
    amount: 2000,
    categoryId: 'entertainment',
    date: '2026-07-20',
    note: 'Gaming arcade & movie night',
    createdAt: '2026-07-20T18:00:00.000Z',
  },

  // --- June 2026 (Total: ₹13,200) ---
  {
    id: 'exp-23',
    amount: 9500,
    categoryId: 'rent',
    date: '2026-06-01',
    note: 'Rent payment',
    createdAt: '2026-06-01T09:00:00.000Z',
  },
  {
    id: 'exp-24',
    amount: 2200,
    categoryId: 'food',
    date: '2026-06-12',
    note: 'Groceries and snacks',
    createdAt: '2026-06-12T10:30:00.000Z',
  },
  {
    id: 'exp-25',
    amount: 1500,
    categoryId: 'transport',
    date: '2026-06-08',
    note: 'Fuel and cab rides',
    createdAt: '2026-06-08T14:00:00.000Z',
  },
];
