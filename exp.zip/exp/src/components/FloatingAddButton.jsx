import React from 'react';
import { Link } from 'react-router-dom';

export default function FloatingAddButton() {
  return (
    <div className="fixed bottom-20 max-w-md w-full pointer-events-none z-40 flex justify-end px-5">
      <Link
        to="/add"
        aria-label="Add new expense"
        className="pointer-events-auto w-14 h-14 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg shadow-primary/35 hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-transform duration-150"
      >
        <span className="material-symbols-outlined text-[28px]">
          add
        </span>
      </Link>
    </div>
  );
}
