import React from 'react';

/**
 * MonthSelector - Month navigation bar with previous/next chevron buttons
 * @param {string} month - "YYYY-MM" (e.g. "2026-11")
 * @param {(newMonth: string) => void} onChange - Month change callback
 * @param {boolean} [canGoNext=false] - Whether next month is selectable (disabled at current month)
 * @param {boolean} [canGoPrev=true] - Whether previous month is selectable
 */
export default function MonthSelector({
  month,
  onChange,
  canGoNext = false,
  canGoPrev = true,
}) {
  // Parse year and month
  const [yearStr, monthStr] = (month || '2026-11').split('-');
  const year = parseInt(yearStr, 10);
  const monthNum = parseInt(monthStr, 10);

  // Month label e.g. "November 2026"
  const dateObj = new Date(year, monthNum - 1, 1);
  const displayLabel = dateObj.toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  });

  const handlePrev = () => {
    if (!canGoPrev) return;
    const prevDate = new Date(year, monthNum - 2, 1);
    const pYear = prevDate.getFullYear();
    const pMonth = String(prevDate.getMonth() + 1).padStart(2, '0');
    onChange(`${pYear}-${pMonth}`);
  };

  const handleNext = () => {
    if (!canGoNext) return;
    const nextDate = new Date(year, monthNum, 1);
    const nYear = nextDate.getFullYear();
    const nMonth = String(nextDate.getMonth() + 1).padStart(2, '0');
    onChange(`${nYear}-${nMonth}`);
  };

  return (
    <section className="flex items-center justify-between bg-surface-card rounded-lg border border-outline px-3 py-2 shadow-xs">
      {/* Previous Month Button */}
      <button
        type="button"
        onClick={handlePrev}
        disabled={!canGoPrev}
        aria-label="Previous month"
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors focus:outline-none ${
          canGoPrev
            ? 'text-muted hover:text-on-surface hover:bg-surface-subtle active:scale-95'
            : 'text-outline cursor-not-allowed'
        }`}
      >
        <span className="material-symbols-outlined text-[20px]">
          chevron_left
        </span>
      </button>

      {/* Center Month Display */}
      <div className="flex items-center gap-2">
        <span className="material-symbols-outlined text-primary text-[18px]">
          event
        </span>
        <h2 className="font-headline text-title-md text-on-surface font-bold tracking-tight">
          {displayLabel}
        </h2>
      </div>

      {/* Next Month Button (Disabled at current month) */}
      <button
        type="button"
        onClick={handleNext}
        disabled={!canGoNext}
        aria-label="Next month"
        className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors focus:outline-none ${
          canGoNext
            ? 'text-muted hover:text-on-surface hover:bg-surface-subtle active:scale-95'
            : 'text-outline cursor-not-allowed'
        }`}
      >
        <span className="material-symbols-outlined text-[20px]">
          chevron_right
        </span>
      </button>
    </section>
  );
}
