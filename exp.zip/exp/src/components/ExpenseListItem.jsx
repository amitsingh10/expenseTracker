import React from 'react';
import { formatExpenseAmount, categories as defaultCategories } from '../data/mockData';
import CategoryIcon from './CategoryIcon';

/**
 * ExpenseListItem - Standard row for displaying an expense
 * Conforms to F4 (no payment method), F10 (no time of day), and F11 (title is note, fallback to category name).
 *
 * @param {object} expense - { id, amount, categoryId, date, note, createdAt }
 * @param {object} [category] - { id, name, color }
 * @param {'list'|'dashboard'} [variant='list']
 * @param {string} [dateLabel] - Derived date label for dashboard variant (e.g. 'Today', 'Yesterday', '14 Nov')
 * @param {() => void} [onClick] - Row click handler (e.g. for edit)
 * @param {(expense: object) => void} [onDelete] - Row delete button handler
 */
export default function ExpenseListItem({
  expense,
  category,
  variant = 'list',
  dateLabel,
  onClick,
  onDelete,
}) {
  if (!expense) return null;

  // Resolve category if not passed
  const resolvedCategory =
    category ||
    defaultCategories.find((c) => c.id === expense.categoryId) || {
      id: expense.categoryId || 'other',
      name: 'Other',
      color: '#10B981',
    };

  // Rule F11: Title is note. If note is empty, show the category name.
  const displayTitle = expense.note && expense.note.trim() ? expense.note : resolvedCategory.name;

  // Derived formatted date if dateLabel not provided
  const formattedDate =
    dateLabel ||
    (expense.date
      ? new Date(expense.date + 'T00:00:00').toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
        })
      : '');

  const isClickable = Boolean(onClick);

  return (
    <div
      onClick={onClick}
      role={isClickable ? 'button' : undefined}
      tabIndex={isClickable ? 0 : undefined}
      onKeyDown={
        isClickable
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
      className={`flex items-center justify-between p-3.5 hover:bg-surface-subtle transition-colors duration-state-change group ${
        isClickable ? 'cursor-pointer focus:outline-none focus:bg-surface-subtle' : 'cursor-default'
      }`}
    >
      <div className="flex items-center space-x-3 min-w-0 flex-1 pr-3">
        {/* Leading CategoryIcon */}
        <CategoryIcon
          categoryId={resolvedCategory.id}
          color={resolvedCategory.color}
          size="md"
        />

        {/* 2-line title and meta */}
        <div className="min-w-0 flex-1">
          <p className="font-label font-semibold text-label-lg text-on-surface truncate">
            {displayTitle}
          </p>

          <p className="font-body text-body-sm text-muted truncate mt-0.5">
            {variant === 'dashboard' ? (
              // Dashboard variant shows date label in meta
              <span>{formattedDate}</span>
            ) : (
              // List variant shows the category name in meta
              <span>{resolvedCategory.name}</span>
            )}
          </p>
        </div>
      </div>

      {/* Right side: Amount in rupees and optional delete action */}
      <div className="flex items-center space-x-2.5 flex-shrink-0">
        <div className="text-right">
          <p className="font-label font-bold text-label-lg text-on-surface tabular-nums">
            {formatExpenseAmount(expense.amount)}
          </p>

          {variant === 'dashboard' && (
            // Dashboard variant shows category under the amount
            <span
              className="text-[10px] font-medium uppercase tracking-wider block mt-0.5"
              style={{ color: resolvedCategory.color }}
            >
              {resolvedCategory.name}
            </span>
          )}
        </div>

        {onDelete && (
          <button
            type="button"
            aria-label={`Delete expense: ${displayTitle}`}
            title="Delete expense"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(expense);
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center text-muted hover:text-red-600 hover:bg-red-50 focus:outline-none focus:ring-1 focus:ring-red-400 transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">
              delete
            </span>
          </button>
        )}
      </div>
    </div>
  );
}
