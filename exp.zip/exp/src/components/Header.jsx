import React from 'react';
import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="sticky top-0 bg-surface/95 backdrop-blur-sm border-b border-outline px-4 py-3 z-40 transition-colors">
      <div className="flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2.5 focus:outline-none">
          {/* 32px primary logo tile */}
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary shadow-xs">
            <span className="material-symbols-outlined text-[20px]">
              account_balance_wallet
            </span>
          </div>
          {/* Uppercase label-sm wordmark in primary */}
          <span className="font-label font-bold text-label-sm tracking-wider uppercase text-primary">
            Tracker
          </span>
        </Link>

        {/* Right 36px circular icon buttons */}
        <div className="flex items-center space-x-2">
          <button
            type="button"
            aria-label="Notifications"
            className="w-9 h-9 rounded-full bg-surface-card border border-outline flex items-center justify-center text-muted hover:text-on-surface hover:bg-surface-subtle transition-colors shadow-xs"
          >
            <span className="material-symbols-outlined text-[18px]">
              notifications
            </span>
          </button>
          <div
            aria-label="User Profile"
            className="w-9 h-9 rounded-full bg-primary-container border border-primary/20 flex items-center justify-center text-on-primary-container font-label font-bold text-xs shadow-xs"
          >
            BK
          </div>
        </div>
      </div>
    </header>
  );
}
