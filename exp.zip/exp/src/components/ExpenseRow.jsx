import React from 'react';
import { categories } from '../data/mockData';

export default function ExpenseRow({ expense, onDelete }) {
  const categoryInfo = categories.find(
    (c) => c.name.toLowerCase() === expense.category.toLowerCase()
  ) || categories[categories.length - 1];

  const formattedAmount = Number(expense.amount).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const formattedDate = new Date(expense.date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
  });

  return (
    <div className="flex items-center justify-between p-3.5 hover:bg-surface-subtle transition-colors group cursor-default">
      <div className="flex items-center space-x-3 min-w-0 flex-1 pr-3">
        {/* 40px Category Icon Circle (Tint + 1px Border) */}
        <div
          className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center border ${categoryInfo.bgTint} ${categoryInfo.borderTint}`}
          style={{ color: categoryInfo.color }}
        >
          <span className="material-symbols-outlined text-[20px]">
            {categoryInfo.icon}
          </span>
        </div>

        {/* 2-line title and meta */}
        <div className="min-w-0 flex-1">
          <p className="font-label font-semibold text-label-lg text-on-surface truncate">
            {expense.title}
          </p>
          <p className="font-body text-body-sm text-muted truncate mt-0.5">
            <span>{categoryInfo.name}</span>
            {expense.paymentMethod && (
              <>
                <span className="mx-1.5">•</span>
                <span>{expense.paymentMethod}</span>
              </>
            )}
            <span className="mx-1.5">•</span>
            <span>{formattedDate}</span>
          </p>
        </div>
      </div>

      {/* Right side: Amount in rupees, tabular-nums */}
      <div className="text-right flex-shrink-0">
        <p className="font-label font-bold text-label-lg text-on-surface tabular-nums">
          -₹{formattedAmount}
        </p>
        <span className="text-[10px] text-muted uppercase tracking-wider block mt-0.5">
          {categoryInfo.name}
        </span>
      </div>
    </div>
  );
}
