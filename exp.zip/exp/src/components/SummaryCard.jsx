import React from 'react';
import { formatCurrency } from '../data/mockData';

/**
 * SummaryCard - Hero monthly total card with decorative blur and metric tiles
 * @param {string} [title="TOTAL SPENT THIS MONTH"]
 * @param {number|string} total - Primary monetary figure
 * @param {number} [expenseCount] - Optional total count of expenses
 * @param {number} [avgPerDay] - Optional daily average
 * @param {Array<{ label: string, value: string|number, isHighlight?: boolean }>} [stats] - Optional custom stat tiles
 * @param {React.ReactNode} [children] - Optional custom elements (e.g. progress bars)
 */
export default function SummaryCard({
  title = 'TOTAL SPENT THIS MONTH',
  total = 0,
  expenseCount,
  avgPerDay,
  stats,
  children,
}) {
  const formattedTotal = typeof total === 'number' ? formatCurrency(total, true) : total;

  // Build stat tiles if not explicitly passed as stats prop
  const derivedStats = stats || [
    typeof avgPerDay !== 'undefined'
      ? {
          label: 'DAILY AVERAGE',
          value: typeof avgPerDay === 'number' ? formatCurrency(Math.round(avgPerDay)) : avgPerDay,
        }
      : null,
    typeof expenseCount !== 'undefined'
      ? {
          label: 'TRANSACTIONS',
          value: `${expenseCount} items`,
        }
      : null,
  ].filter(Boolean);

  return (
    <div className="bg-surface-card border border-outline rounded-lg p-6 shadow-sm relative overflow-hidden">
      {/* Decorative soft blurred primary-container circle at bottom right */}
      <div
        aria-hidden="true"
        className="w-32 h-32 bg-primary-container/40 rounded-full blur-2xl absolute -bottom-6 -right-6 pointer-events-none"
      />

      <div className="relative z-10">
        <p className="font-label text-label-sm uppercase tracking-wider text-muted font-medium">
          {title}
        </p>

        <div className="mt-1 flex items-baseline justify-between">
          <p className="font-display font-bold text-display-lg-mobile sm:text-display-lg text-on-surface tabular-nums tracking-tight">
            {formattedTotal}
          </p>
        </div>

        {/* Optional custom slot (e.g., progress bar or subtext) */}
        {children && <div className="mt-3">{children}</div>}

        {/* Stat Tiles: 2-column grid */}
        {derivedStats.length > 0 && (
          <div className="grid grid-cols-2 gap-3 mt-4">
            {derivedStats.map((stat, idx) => (
              <div
                key={stat.label || idx}
                className="bg-surface-subtle/70 rounded-md border border-outline/50 p-3"
              >
                <p className="font-label text-[11px] uppercase tracking-wider text-muted font-medium">
                  {stat.label}
                </p>
                <p
                  className={`font-headline font-semibold text-headline-sm tabular-nums mt-0.5 truncate ${
                    stat.isHighlight ? 'text-primary' : 'text-on-surface'
                  }`}
                >
                  {stat.value}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
