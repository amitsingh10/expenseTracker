import React from 'react';
import { NavLink } from 'react-router-dom';

const navItems = [
  { path: '/', label: 'Dashboard', icon: 'dashboard' },
  { path: '/expenses', label: 'Expenses', icon: 'receipt_long' },
  { path: '/add', label: 'Add', icon: 'add_circle' },
  { path: '/reports', label: 'Reports', icon: 'bar_chart' },
];

export default function Navbar() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto w-full bg-surface-card border-t border-outline z-50 px-4 py-2">
      <div className="flex justify-around items-center">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 py-1 transition-all duration-150 ${
                isActive
                  ? 'text-primary'
                  : 'text-muted hover:text-on-surface'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={`material-symbols-outlined text-[22px] transition-transform ${
                    isActive ? 'fill' : ''
                  }`}
                >
                  {item.icon}
                </span>
                <span
                  className={`font-label text-label-sm mt-0.5 ${
                    isActive ? 'font-semibold text-primary' : 'font-medium text-muted'
                  }`}
                  {...(isActive ? { 'aria-current': 'page' } : {})}
                >
                  {item.label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
