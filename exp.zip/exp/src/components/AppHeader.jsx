import React from 'react';
import { Link, NavLink } from 'react-router-dom';

const navItems = [
  { path: '/', label: 'Dashboard', icon: 'dashboard' },
  { path: '/expenses', label: 'Expenses', icon: 'receipt_long' },
  { path: '/reports', label: 'Reports', icon: 'bar_chart' },
];

/**
 * AppHeader - Responsive top bar with branding, desktop navigation links, and right action buttons
 * @param {Array<{ icon: string, label: string, onClick?: () => void, ariaLabel?: string }>} rightActions
 * @param {string} [title="EXPENSE TRACKER"]
 * @param {boolean} [showLogo=true]
 */
export default function AppHeader({
  rightActions = [],
  title = 'EXPENSE TRACKER',
  showLogo = true,
}) {
  return (
    <header className="sticky top-0 bg-surface/95 backdrop-blur-sm border-b border-outline px-4 sm:px-6 md:px-8 py-3 z-40 transition-colors">
      <div className="flex items-center justify-between max-w-6xl mx-auto w-full">
        {/* Left: Brand Logo & Title */}
        <Link to="/" className="flex items-center space-x-2.5 focus:outline-none flex-shrink-0">
          {showLogo && (
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary shadow-xs flex-shrink-0">
              <span className="material-symbols-outlined text-[20px]">
                account_balance_wallet
              </span>
            </div>
          )}
          <span className="font-label font-bold text-label-sm tracking-wider uppercase text-primary truncate">
            {title}
          </span>
        </Link>

        {/* Center: Desktop Navigation Tabs (Visible on md+ screens) */}
        <nav
          aria-label="Desktop Navigation"
          className="hidden md:flex items-center space-x-1 lg:space-x-2 bg-surface-subtle/80 p-1 rounded-lg border border-outline/50"
        >
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `flex items-center space-x-1.5 px-3.5 py-1.5 rounded-md font-label text-label-sm transition-all duration-state-change ${
                  isActive
                    ? 'bg-surface-card text-primary font-bold shadow-xs'
                    : 'text-muted hover:text-on-surface hover:bg-surface-card/50 font-medium'
                }`
              }
            >
              <span className="material-symbols-outlined text-[18px]">
                {item.icon}
              </span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* Right: Desktop Action Button & Icons */}
        <div className="flex items-center space-x-2.5">
          {/* Desktop "+ Add Expense" shortcut */}
          <Link
            to="/expenses/new"
            className="hidden md:inline-flex items-center space-x-1.5 bg-primary text-white font-label text-label-sm font-semibold px-3.5 py-1.5 rounded shadow-sm hover:opacity-95 active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">add</span>
            <span>Add Expense</span>
          </Link>

          {/* Right Action Icons (Notifications, Calendar Filter) */}
          {rightActions && rightActions.length > 0 && (
            <div className="flex items-center space-x-2">
              {rightActions.map((action, idx) => (
                <button
                  key={action.label || idx}
                  type="button"
                  onClick={action.onClick}
                  aria-label={action.ariaLabel || action.label}
                  title={action.label}
                  className="w-9 h-9 rounded-full bg-surface-card border border-outline flex items-center justify-center text-muted hover:text-on-surface hover:bg-surface-subtle transition-colors shadow-xs focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  <span className="material-symbols-outlined text-[18px]">
                    {action.icon}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
