import React from 'react';
import { iconByCategoryId, categoryTints } from '../data/mockData';

/**
 * CategoryIcon - Tinted circle with category icon derived from categoryId and color
 * @param {string} categoryId - e.g. 'food', 'transport', 'rent'
 * @param {string} [color] - Optional hex color override
 * @param {'sm'|'md'|'lg'} [size='md'] - 'sm' (32px), 'md' (40px), 'lg' (48px)
 * @param {string} [className='']
 */
export default function CategoryIcon({
  categoryId,
  color,
  size = 'md',
  className = '',
}) {
  const icon = iconByCategoryId[categoryId] || 'receipt_long';
  const tint = categoryTints[categoryId] || {
    bg: 'bg-emerald-50',
    border: 'border-emerald-100',
    text: 'text-emerald-800',
  };

  const sizeClasses = {
    sm: 'w-8 h-8 rounded-full',
    md: 'w-10 h-10 rounded-full',
    lg: 'w-12 h-12 rounded-xl',
  }[size] || 'w-10 h-10 rounded-full';

  const iconSizes = {
    sm: 'text-[16px]',
    md: 'text-[20px]',
    lg: 'text-[24px]',
  }[size] || 'text-[20px]';

  return (
    <div
      className={`${sizeClasses} flex-shrink-0 flex items-center justify-center border ${tint.bg} ${tint.border} ${className}`}
      style={{ color: color || undefined }}
      aria-hidden="true"
    >
      <span className={`material-symbols-outlined ${iconSizes}`}>
        {icon}
      </span>
    </div>
  );
}
