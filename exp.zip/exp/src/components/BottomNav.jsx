import React from 'react';
import { NavLink } from 'react-router-dom';

const defaultTabs = [
  { path: '/', label: 'Home', icon: 'home' },
  { path: '/expenses', label: 'Expenses', icon: 'receipt_long' },
  { path: '/reports', label: 'Reports', icon: 'bar_chart' },
];

/**
 * BottomNav - Fixed bottom navigation bar for mobile screens (hidden on md+ screens)
 * @param {Array<{ path: string, label: string, icon: string }>} [tabs=defaultTabs]
 */
export default function BottomNav({ tabs = defaultTabs }) {
  return (
    <nav
      aria-label="Mobile Bottom Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 w-full bg-surface-card border-t border-outline z-50 px-page-margin py-2"
    >
      <div className="max-w-md mx-auto flex justify-around items-center">
        {tabs.map((tab) => (
          <NavLink
            key={tab.path}
            to={tab.path}
            end={tab.path === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 py-1 transition-all duration-state-change ${
                isActive ? 'text-primary' : 'text-muted hover:text-on-surface'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span
                  className={`material-symbols-outlined text-[22px] transition-transform ${
                    isActive ? 'fill' : ''
                  }`}
                >
                  {tab.icon}
                </span>
                <span
                  className={`font-label text-label-sm mt-0.5 ${
                    isActive ? 'font-semibold text-primary' : 'font-medium text-muted'
                  }`}
                  {...(isActive ? { 'aria-current': 'page' } : {})}
                >
                  {tab.label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
