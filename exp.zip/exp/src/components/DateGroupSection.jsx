import React from 'react';
import { formatCurrency } from '../data/mockData';
import ExpenseListItem from './ExpenseListItem';

/**
 * DateGroupSection - Group header with day subtotal and container for expense rows
 * @param {string} [date] - ISO date string ('YYYY-MM-DD')
 * @param {string} label - Display label ('Today', 'Yesterday', '14 Nov')
 * @param {string} [weekday] - Weekday abbreviation ('Sat', 'Sun')
 * @param {number|string} subtotal - Sum of expenses for this date
 * @param {boolean} [isToday=false] - Whether this date is today (shows primary green dot)
 * @param {Array<object>} [expenses] - Optional array of expense objects to render
 * @param {Array<object>} [categories] - Optional categories lookup
 * @param {(expense: object) => void} [onExpenseClick] - Click handler for each row
 * @param {React.ReactNode} [children] - Optional custom child elements
 */
export default function DateGroupSection({
  date,
  label,
  weekday,
  subtotal = 0,
  isToday = false,
  expenses = [],
  categories = [],
  onExpenseClick,
  children,
}) {
  const formattedSubtotal =
    typeof subtotal === 'number' ? formatCurrency(subtotal) : subtotal;

  return (
    <section className="space-y-1.5" aria-labelledby={date ? `date-${date}` : undefined}>
      {/* Date Group Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center space-x-2">
          {/* 8px Status Dot: primary for today, outline-strong otherwise */}
          <span
            className={`w-2 h-2 rounded-full flex-shrink-0 ${
              isToday ? 'bg-primary' : 'bg-outline-strong'
            }`}
            aria-hidden="true"
          />

          <h2
            id={date ? `date-${date}` : undefined}
            className="font-title font-semibold text-title-md text-on-surface"
          >
            {label}
          </h2>

          {weekday && (
            <span className="font-body text-[11px] text-muted">
              {weekday}
            </span>
          )}
        </div>

        {/* Right-aligned Subtotal */}
        <div className="font-label text-label-sm text-muted">
          Subtotal:{' '}
          <span className="font-semibold text-on-surface tabular-nums">
            {formattedSubtotal}
          </span>
        </div>
      </div>

      {/* List Container: surface-card, rounded-lg, 1px outline, 1px dividers, shadow-sm */}
      <div className="bg-surface-card border border-outline rounded-lg shadow-sm divide-y divide-outline overflow-hidden">
        {children
          ? children
          : expenses.map((item) => {
              const category = categories.find((c) => c.id === item.categoryId);
              return (
                <ExpenseListItem
                  key={item.id}
                  expense={item}
                  category={category}
                  variant="list"
                  onClick={onExpenseClick ? () => onExpenseClick(item) : undefined}
                />
              );
            })}
      </div>
    </section>
  );
}
