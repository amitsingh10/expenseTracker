import React from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * FormHeader - Sticky contextual top bar for form screens with back arrow
 * @param {string} [title="Add Expense"]
 * @param {() => void} [onClose] - Custom close/back handler (defaults to navigate(-1))
 * @param {() => void} [onReset] - Reset form handler
 */
export default function FormHeader({
  title = 'Add Expense',
  onClose,
  onReset,
}) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onClose) {
      onClose();
    } else {
      navigate(-1);
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-surface/95 backdrop-blur-sm border-b border-outline px-4 sm:px-6 md:px-8 py-3">
      <div className="flex items-center justify-between max-w-md sm:max-w-xl md:max-w-2xl mx-auto">
        {/* Left: 36px Circular Back Arrow button */}
        <button
          type="button"
          onClick={handleBack}
          aria-label="Go to previous page"
          title="Go back"
          className="w-9 h-9 rounded-full bg-surface-card border border-outline flex items-center justify-center text-muted hover:text-on-surface hover:bg-surface-subtle transition-colors shadow-xs focus:outline-none focus:ring-1 focus:ring-primary"
        >
          <span className="material-symbols-outlined text-[20px]">
            arrow_back
          </span>
        </button>

        {/* Center: Title */}
        <h1 className="font-headline text-title-md text-on-surface font-bold">
          {title}
        </h1>

        {/* Right: Reset Button */}
        {onReset ? (
          <button
            type="button"
            onClick={onReset}
            aria-label="Reset Form"
            className="text-label-sm font-label text-muted hover:text-primary font-semibold transition-colors focus:outline-none"
          >
            Reset
          </button>
        ) : (
          <div className="w-9" aria-hidden="true" />
        )}
      </div>
    </header>
  );
}
