import React from 'react';
import { Link } from 'react-router-dom';

/**
 * AddExpenseFab - Floating action button pinned above bottom nav on mobile, corner on desktop
 * @param {string} [to="/expenses/new"] - Target route
 * @param {() => void} [onClick] - Optional click handler
 * @param {string} [ariaLabel="Add new expense"]
 * @param {string} [className=""]
 */
export default function AddExpenseFab({
  to = '/expenses/new',
  onClick,
  ariaLabel = 'Add new expense',
  className = '',
}) {
  const content = (
    <span className="material-symbols-outlined text-[28px] select-none">
      add
    </span>
  );

  const baseClasses = `pointer-events-auto w-14 h-14 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg shadow-primary/35 hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition-transform duration-state-change ${className}`;

  return (
    <div className="fixed bottom-20 md:bottom-8 right-5 md:right-8 lg:right-12 z-40 pointer-events-none flex justify-end">
      {to ? (
        <Link
          to={to}
          onClick={onClick}
          aria-label={ariaLabel}
          className={baseClasses}
        >
          {content}
        </Link>
      ) : (
        <button
          type="button"
          onClick={onClick}
          aria-label={ariaLabel}
          className={baseClasses}
        >
          {content}
        </button>
      )}
    </div>
  );
}
