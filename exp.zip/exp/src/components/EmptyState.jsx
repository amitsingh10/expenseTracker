import React from 'react';
import { Link } from 'react-router-dom';

/**
 * EmptyState - Reusable empty and no-results placeholder
 * @param {string} title - Heading text
 * @param {string} [message] - Subtitle explanation
 * @param {string} [icon="receipt_long"] - Material symbol name
 * @param {string} [actionLabel] - Optional button text
 * @param {() => void} [onAction] - Optional click handler
 * @param {string} [actionTo] - Optional router destination
 * @param {string} [className=""]
 */
export default function EmptyState({
  title,
  message,
  icon = 'receipt_long',
  actionLabel,
  onAction,
  actionTo,
  className = '',
}) {
  return (
    <div
      className={`bg-surface-card border border-outline rounded-lg p-8 text-center shadow-sm flex flex-col items-center justify-center ${className}`}
    >
      <span
        className="material-symbols-outlined text-[48px] text-muted select-none"
        aria-hidden="true"
      >
        {icon}
      </span>

      {title && (
        <h3 className="font-title font-semibold text-title-md text-on-surface mt-2">
          {title}
        </h3>
      )}

      {message && (
        <p className="font-body text-body-md text-muted mt-1 max-w-xs">
          {message}
        </p>
      )}

      {actionLabel && (
        <div className="mt-4">
          {actionTo ? (
            <Link
              to={actionTo}
              className="inline-flex items-center space-x-1.5 font-label text-label-sm font-semibold text-primary hover:underline transition-colors focus:outline-none"
            >
              <span>{actionLabel}</span>
            </Link>
          ) : (
            <button
              type="button"
              onClick={onAction}
              className="inline-flex items-center space-x-1.5 font-label text-label-sm font-semibold text-primary hover:underline transition-colors focus:outline-none"
            >
              <span>{actionLabel}</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
}
