import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import AppHeader from './components/AppHeader';
import BottomNav from './components/BottomNav';
import Dashboard from './pages/Dashboard';
import AddExpense from './pages/AddExpense';
import ExpenseList from './pages/ExpenseList';
import Reports from './pages/Reports';

const headerActions = [
  { icon: 'notifications', label: 'Notifications' },
  { icon: 'calendar_month', label: 'Calendar Filter' },
];

export default function App() {
  const location = useLocation();
  const isFormScreen = location.pathname.startsWith('/expenses/new') || location.pathname.includes('/edit');

  return (
    <div className="min-h-screen bg-slate-100 flex justify-center selection:bg-primary-container selection:text-on-primary-container">
      {/* Responsive container: max-w-md on mobile, expands smoothly up to max-w-6xl on desktop */}
      <div className="w-full max-w-md md:max-w-4xl lg:max-w-5xl xl:max-w-6xl min-h-screen bg-surface md:border-x md:border-outline md:shadow-sm flex flex-col relative transition-all duration-200">
        {/* Only show global AppHeader on non-form screens (Add/Edit has FormHeader) */}
        {!isFormScreen && <AppHeader rightActions={headerActions} />}

        {/* Page Content */}
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/expenses" element={<ExpenseList />} />
            <Route path="/expenses/new" element={<AddExpense />} />
            <Route path="/expenses/edit/:id" element={<AddExpense />} />
            <Route path="/expenses/:id/edit" element={<AddExpense />} />
            <Route path="/add" element={<Navigate to="/expenses/new" replace />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        {/* Only show BottomNav on non-form screens (auto-hidden on md+ screens) */}
        {!isFormScreen && <BottomNav />}
      </div>
    </div>
  );
}
